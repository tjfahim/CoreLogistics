

<?php $__env->startSection('main_content'); ?>
<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">

            
            <div class="col-md-3">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Groups</strong>
                    </div>
                    <div class="list-group list-group-flush">
                        <a href="<?php echo e(route('permissions.index')); ?>"
                           class="list-group-item list-group-item-action <?php echo e(!request('group') ? 'active' : ''); ?>">
                            All Permissions
                            <span class="badge badge-secondary float-right"><?php echo e($groupCounts->sum()); ?></span>
                        </a>
                        <?php $__currentLoopData = $groupNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupName): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a href="<?php echo e(route('permissions.index', ['group' => $groupName])); ?>"
                               class="list-group-item list-group-item-action <?php echo e(request('group') == $groupName ? 'active' : ''); ?>">
                                <?php echo e($groupName); ?>

                                <span class="badge badge-secondary float-right">
                                    <?php echo e($groupCounts[$groupName] ?? 0); ?>

                                </span>
                            </a>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>

            
            <div class="col-md-9">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <strong class="card-title">
                            Permissions
                            <?php if(request('group')): ?>
                                - <span class="text-primary"><?php echo e(request('group')); ?></span>
                            <?php endif; ?>
                        </strong>
                        <div>
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bulk-create-permissions')): ?>
                                <a href="#" class="btn btn-outline-primary btn-sm"
                                   data-toggle="modal" data-target="#bulkModal">
                                    <i class="fa fa-layer-group"></i> Bulk Create
                                </a>
                            <?php endif; ?>

                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-permissions')): ?>
                                <a href="<?php echo e(route('permissions.create')); ?>" class="btn btn-primary btn-sm">
                                    <i class="fa fa-plus"></i> Add Permission
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="card-body">

                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <?php echo e(session('error')); ?>

                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                            </div>
                        <?php endif; ?>

                        
                        <form method="GET" action="<?php echo e(route('permissions.index')); ?>" class="mb-3">
                            <div class="input-group">
                                <input type="text" name="search" class="form-control"
                                       placeholder="Search name, slug, or group..."
                                       value="<?php echo e(request('search')); ?>">
                                <?php if(request('group')): ?>
                                    <input type="hidden" name="group" value="<?php echo e(request('group')); ?>">
                                <?php endif; ?>
                                <div class="input-group-append">
                                    <button class="btn btn-outline-secondary" type="submit">
                                        <i class="fa fa-search"></i>
                                    </button>
                                    <?php if(request('search') || request('group')): ?>
                                        <a href="<?php echo e(route('permissions.index')); ?>" class="btn btn-outline-danger">
                                            <i class="fa fa-times"></i>
                                        </a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>

                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th width="50">#</th>
                                    <th>Name</th>
                                    <th>Slug</th>
                                    <th width="200">Group</th>
                                    <th width="100">Roles</th>
                                    <th width="170">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($permissions->firstItem() + $key); ?></td>
                                    <td><?php echo e($permission->name); ?></td>
                                    <td><code><?php echo e($permission->slug); ?></code></td>
                                    <td>
                                        <a href="<?php echo e(route('permissions.index', ['group' => $permission->group_name])); ?>"
                                           class="badge badge-info">
                                            <?php echo e($permission->group_name); ?>

                                        </a>
                                    </td>
                                    <td>
                                        <span class="badge badge-secondary">
                                            <?php echo e($permission->roles_count ?? $permission->roles()->count()); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-permissions')): ?>
                                                <a href="<?php echo e(route('permissions.show', $permission->id)); ?>"
                                                   class="btn btn-info btn-sm" title="View">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            <?php endif; ?>

                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-permissions')): ?>
                                                <a href="<?php echo e(route('permissions.edit', $permission->id)); ?>"
                                                   class="btn btn-warning btn-sm" title="Edit">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                            <?php endif; ?>

                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-permissions')): ?>
                                                <form action="<?php echo e(route('permissions.destroy', $permission->id)); ?>"
                                                      method="POST" class="d-inline delete-form">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted">No permissions found.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <div class="mt-3">
                            <?php echo e($permissions->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('bulk-create-permissions')): ?>
<div class="modal fade" id="bulkModal" tabindex="-1">
    <div class="modal-dialog">
        <form action="<?php echo e(route('permissions.bulk-store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Bulk Create Permissions</h5>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <div class="modal-body">
                    <div class="form-group">
                        <label>Group Name <span class="text-danger">*</span></label>
                        <input type="text" name="group_name" class="form-control"
                               list="groupList" value="<?php echo e(request('group')); ?>" required>
                        <datalist id="groupList">
                            <?php $__currentLoopData = $groupNames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $g): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($g); ?>">
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </datalist>
                    </div>

                    <label>Permissions <span class="text-danger">*</span></label>
                    <div id="bulkRows">
                        <div class="input-group mb-2">
                            <input type="text" name="permissions[0][name]" class="form-control"
                                   placeholder="e.g. view-users" required>
                            <div class="input-group-append">
                                <button type="button" class="btn btn-outline-danger remove-row">
                                    <i class="fa fa-times"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <button type="button" class="btn btn-sm btn-outline-primary" id="addRow">
                        <i class="fa fa-plus"></i> Add another
                    </button>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Create</button>
                </div>
            </div>
        </form>
    </div>
</div>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
        // Delete confirm
        $('.delete-form').on('submit', function (e) {
            e.preventDefault();
            if (confirm('Are you sure you want to delete this permission?')) {
                this.submit();
            }
        });

        // Bulk rows
        var rowIndex = 1;
        $('#addRow').on('click', function () {
            var html = '<div class="input-group mb-2">' +
                '<input type="text" name="permissions[' + rowIndex + '][name]" class="form-control" placeholder="e.g. edit-users" required>' +
                '<div class="input-group-append">' +
                '<button type="button" class="btn btn-outline-danger remove-row"><i class="fa fa-times"></i></button>' +
                '</div></div>';
            $('#bulkRows').append(html);
            rowIndex++;
        });

        $(document).on('click', '.remove-row', function () {
            if ($('#bulkRows .input-group').length > 1) {
                $(this).closest('.input-group').remove();
            }
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/permissions/index.blade.php ENDPATH**/ ?>