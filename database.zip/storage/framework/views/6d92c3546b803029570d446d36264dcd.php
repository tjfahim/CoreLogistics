

<?php $__env->startSection('main_content'); ?>
<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <strong class="card-title">User Management</strong>

                        
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-users')): ?>
                            <a href="<?php echo e(route('users.create')); ?>" class="btn btn-primary btn-sm">
                                <i class="fa fa-plus"></i> Add New User
                            </a>
                        <?php endif; ?>
                    </div>
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <?php echo e(session('error')); ?>

                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                            </div>
                        <?php endif; ?>

                        <table class="table table-striped table-bordered" id="userTable">
                            <thead>
                                <tr>
                                    <th>#</th>
                                    <th>Image</th>
                                    <th>Name</th>
                                    <th>Email</th>
                                    <th>Role</th>
                                    <th>Status</th>
                                    <th>Created</th>
                                    <th>Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($users->firstItem() + $key); ?></td>
                                    <td>
                                        <img src="<?php echo e($user->image_url); ?>"
                                             alt="<?php echo e($user->name); ?>"
                                             class="rounded-circle"
                                             style="width: 40px; height: 40px; object-fit: cover;">
                                    </td>
                                    <td><?php echo e($user->name); ?></td>
                                    <td><?php echo e($user->email); ?></td>
                                    <td>
                                        <?php if($user->roleRelation): ?>
                                            <?php
                                                $badgeClass = match($user->roleRelation->slug) {
                                                    'superadmin' => 'badge-dark',
                                                    'admin'      => 'badge-success',
                                                    'manager'    => 'badge-primary',
                                                    default      => 'badge-secondary',
                                                };
                                            ?>
                                            <span class="badge <?php echo e($badgeClass); ?>">
                                                <?php echo e($user->roleRelation->name); ?>

                                            </span>
                                        <?php elseif($user->role == 2): ?>
                                            <span class="badge badge-success">Admin (legacy)</span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">User</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('toggle-user-status')): ?>
                                            <span class="badge <?php echo e($user->status == 1 ? 'badge-success' : 'badge-danger'); ?> status-badge"
                                                  data-id="<?php echo e($user->id); ?>"
                                                  style="cursor:pointer;">
                                                <?php echo e($user->status == 1 ? 'Active' : 'Inactive'); ?>

                                            </span>
                                        <?php else: ?>
                                            <span class="badge <?php echo e($user->status == 1 ? 'badge-success' : 'badge-danger'); ?>">
                                                <?php echo e($user->status == 1 ? 'Active' : 'Inactive'); ?>

                                            </span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($user->created_at->format('d M Y')); ?></td>
                                    <td>
                                        <div class="btn-group">
                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-users')): ?>
                                                <a href="<?php echo e(route('users.show', $user->id)); ?>"
                                                   class="btn btn-info btn-sm" title="View">
                                                    <i class="fa fa-eye"></i>
                                                </a>
                                            <?php endif; ?>

                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-users')): ?>
                                                <a href="<?php echo e(route('users.edit', $user->id)); ?>"
                                                   class="btn btn-warning btn-sm" title="Edit">
                                                    <i class="fa fa-edit"></i>
                                                </a>
                                            <?php endif; ?>

                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-users')): ?>
                                                <?php if(auth()->id() !== $user->id): ?>
                                                <form action="<?php echo e(route('users.destroy', $user->id)); ?>"
                                                      method="POST"
                                                      class="d-inline delete-form">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm" title="Delete">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                        <div class="mt-3">
                            <?php echo e($users->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function() {
        $('.delete-form').on('submit', function(e) {
            e.preventDefault();
            if (confirm('Are you sure you want to delete this user?')) {
                this.submit();
            }
        });

        $('.status-badge').on('click', function() {
            var badge = $(this);
            var userId = badge.data('id');

            $.ajax({
                url: '/admin/users/' + userId + '/toggle-status',
                type: 'POST',
                data: { _token: '<?php echo e(csrf_token()); ?>' },
                success: function(response) {
                    if (response.success) {
                        if (response.status == 1) {
                            badge.removeClass('badge-danger').addClass('badge-success').text('Active');
                        } else {
                            badge.removeClass('badge-success').addClass('badge-danger').text('Inactive');
                        }
                    }
                },
                error: function(xhr) {
                    alert(xhr.responseJSON.error || 'Something went wrong');
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/users/index.blade.php ENDPATH**/ ?>