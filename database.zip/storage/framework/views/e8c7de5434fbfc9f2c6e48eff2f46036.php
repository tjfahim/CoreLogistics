<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
    <h1 class="h3 mb-3">Old Excel Uploads</h1>

    <?php $__currentLoopData = ['success','error']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(session($m)): ?> <div class="alert alert-<?php echo e($m === 'error' ? 'danger' : 'success'); ?>"><?php echo e(session($m)); ?></div> <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php if($errors->any()): ?> <div class="alert alert-danger"><?php echo e($errors->first()); ?></div> <?php endif; ?>

    
    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-old-data')): ?>
        <div class="card shadow mb-4">
            <div class="card-header"><strong>Upload old Excel (the *_import_ready.xlsx file)</strong></div>
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('legacy.store')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <div class="form-row">
                        <div class="form-group col-md-4">
                            <label>Excel file (.xlsx)</label>
                            <input type="file" name="file" class="form-control-file" accept=".xlsx" required>
                        </div>
                        <div class="form-group col-md-3">
                            <label>Title</label>
                            <input type="text" name="title" class="form-control" placeholder="June 2026 deliveries">
                        </div>
                        <div class="form-group col-md-3">
                            <label>Note</label>
                            <input type="text" name="note" class="form-control">
                        </div>
                        <div class="form-group col-md-2 d-flex align-items-end">
                            <button class="btn btn-primary btn-block">Upload &amp; Read</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    <?php endif; ?>

    <div class="card shadow">
        <div class="card-body table-responsive">
            <table class="table table-bordered table-sm">
                <thead class="thead-light">
                <tr>
                    <th>Title</th><th>Status</th><th class="text-right">Rows</th><th class="text-right">Errors</th>
                    <th class="text-right">Billed</th><th class="text-right">Paid</th><th class="text-right">Due</th>
                    <th>Uploaded</th><th></th>
                </tr>
                </thead>
                <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $uploads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($u->title); ?><br><small class="text-muted"><?php echo e($u->file_name); ?></small></td>
                        <td>
                            <span class="badge badge-<?php echo e(['staged'=>'warning','approved'=>'info','imported'=>'success'][$u->status]); ?>"><?php echo e(ucfirst($u->status)); ?></span>
                        </td>
                        <td class="text-right"><?php echo e($u->total_rows); ?></td>
                        <td class="text-right <?php echo e($u->error_rows ? 'text-danger font-weight-bold' : ''); ?>"><?php echo e($u->error_rows); ?></td>
                        <td class="text-right"><?php echo e(number_format($u->total_billed, 0)); ?></td>
                        <td class="text-right"><?php echo e(number_format($u->total_paid, 0)); ?></td>
                        <td class="text-right"><?php echo e(number_format($u->total_due, 0)); ?></td>
                        <td><?php echo e($u->created_at->format('d M Y H:i')); ?></td>
                        <td class="text-nowrap">
                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-old-data')): ?>
                                <a href="<?php echo e(route('legacy.show', $u)); ?>" class="btn btn-sm btn-outline-primary">Review</a>
                            <?php endif; ?>

                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-old-data')): ?>
                                <?php if($u->status !== 'staged'): ?>
                                    <a href="<?php echo e(route('legacy.report', $u)); ?>" class="btn btn-sm btn-info">Report</a>
                                <?php endif; ?>
                            <?php endif; ?>

                            
                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-old-data')): ?>
                                <a href="<?php echo e(route('legacy.download', $u)); ?>" class="btn btn-sm btn-outline-secondary">File</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr><td colspan="9" class="text-center text-muted">Nothing uploaded yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/legacy/index.blade.php ENDPATH**/ ?>