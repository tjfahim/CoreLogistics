<aside id="left-panel" class="tl-sidebar">
    <div class="tl-brand">
        <a href="/admin/dashboard">
            <img class="tl-logo-full" src="<?php echo e(asset('admin/images/logo.png')); ?>" alt="Logo">
            <img class="tl-logo-mini" src="<?php echo e(asset('admin/images/logo2.png')); ?>" alt="Logo">
        </a>
    </div>

    <div class="tl-scroll">
        <ul class="tl-nav">

            
            <li class="tl-item <?php echo e(request()->is('admin/dashboard') || request()->is('/') ? 'active' : ''); ?>">
                <a href="/admin/dashboard" title="Dashboard">
                    <span class="tl-ico"><i class="fa fa-dashboard"></i></span><span class="tl-txt">Dashboard</span>
                </a>
            </li>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-warehouse')): ?>
            <li class="tl-title">Warehouse</li>
            <li class="tl-item <?php echo e(request()->routeIs('cargo-items.*') && !request()->routeIs('cargo-items.arrived-bd') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('cargo-items.index')); ?>" title="China Warehouse">
                    <span class="tl-ico"><i class="fa fa-cubes"></i></span><span class="tl-txt">China Warehouse</span>
                </a>
            </li>
            <li class="tl-item <?php echo e(request()->routeIs('cargo-items.arrived-bd') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('cargo-items.arrived-bd')); ?>" title="BD Warehouse">
                    <span class="tl-ico"><i class="fa fa-building"></i></span><span class="tl-txt">BD Warehouse</span>
                </a>
            </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-shipments')): ?>
            <li class="tl-title">Operations</li>
            <li class="tl-item <?php echo e(request()->routeIs('itemsshipments.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('itemsshipments.index')); ?>" title="Shipments">
                    <span class="tl-ico"><i class="fa fa-ship"></i></span><span class="tl-txt">Shipments</span>
                </a>
            </li>
            <?php endif; ?>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view-reports', 'view-legacy-uploads'])): ?>
            <li class="tl-title">Reports</li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-reports')): ?>
            <li class="tl-item <?php echo e(request()->routeIs('reports.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('reports.dashboard')); ?>" title="Dashboard Reports">
                    <span class="tl-ico"><i class="fa fa-bar-chart"></i></span><span class="tl-txt">Dashboard Reports</span>
                </a>
            </li>
            <?php endif; ?>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-legacy-uploads')): ?>
            <li class="tl-item <?php echo e(request()->routeIs('legacy.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('legacy.index')); ?>" title="Legacy Uploads">
                    <span class="tl-ico"><i class="fa fa-history"></i></span><span class="tl-txt">Legacy Uploads</span>
                </a>
            </li>
            <?php endif; ?>
            <?php endif; ?>

            
            <li class="tl-title">Accounting</li>
            <li class="tl-item <?php echo e(request()->routeIs('ledger.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('ledger.index')); ?>" title="Customer Ledger">
                    <span class="tl-ico"><i class="fa fa-book"></i></span><span class="tl-txt">Customer Ledger</span>
                </a>
            </li>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view-users', 'view-roles', 'view-permissions', 'view-customers', 'view-shipping-mark', 'view-agents', 'view-cost-types'])): ?>
            <li class="tl-title">Master data</li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-users')): ?>
            <li class="tl-item <?php echo e(request()->routeIs('users.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('users.index')); ?>" title="Admin Users">
                    <span class="tl-ico"><i class="fa fa-user-circle"></i></span><span class="tl-txt">Admin Users</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-roles')): ?>
            <li class="tl-item <?php echo e(request()->routeIs('roles.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('roles.index')); ?>" title="Roles">
                    <span class="tl-ico"><i class="fa fa-shield"></i></span><span class="tl-txt">Roles</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-permissions')): ?>
            <li class="tl-item <?php echo e(request()->routeIs('permissions.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('permissions.index')); ?>" title="Permissions">
                    <span class="tl-ico"><i class="fa fa-key"></i></span><span class="tl-txt">Permissions</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-customers')): ?>
            <li class="tl-item <?php echo e(request()->routeIs('customers.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('customers.index')); ?>" title="Customers">
                    <span class="tl-ico"><i class="fa fa-users"></i></span><span class="tl-txt">Customers</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-shipping-mark')): ?>
            <li class="tl-item <?php echo e(request()->routeIs('customer-extra-shipping-marks.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('customer-extra-shipping-marks.index')); ?>" title="Extra Shipping Marks">
                    <span class="tl-ico"><i class="fa fa-tags"></i></span><span class="tl-txt">Extra Shipping Marks</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-agents')): ?>
            <li class="tl-item <?php echo e(request()->routeIs('agents.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('agents.index')); ?>" title="Agents">
                    <span class="tl-ico"><i class="fa fa-handshake-o"></i></span><span class="tl-txt">Agents</span>
                </a>
            </li>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-cost-types')): ?>
            <li class="tl-item <?php echo e(request()->routeIs('cost-types.*') ? 'active' : ''); ?>">
                <a href="<?php echo e(route('cost-types.index')); ?>" title="Cost Types">
                    <span class="tl-ico"><i class="fa fa-list-alt"></i></span><span class="tl-txt">Cost Types</span>
                </a>
            </li>
            <?php endif; ?>

        </ul>
    </div>
</aside><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>