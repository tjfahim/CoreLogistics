

<?php $__env->startSection('main_content'); ?>
<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Imported Excel Files</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="<?php echo e(route('cargo-items.create')); ?>">Add Items</a></li>
                    <li class="active">Imported Files</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <?php if(session('success')): ?>
        <div class="col-sm-12">
            <div class="alert alert-success alert-dismissible fade show">
                <span class="badge badge-pill badge-success">Success</span>
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
            </div>
        </div>
    <?php endif; ?>
    <?php if(session('error')): ?>
        <div class="col-sm-12">
            <div class="alert alert-danger alert-dismissible fade show">
                <span class="badge badge-pill badge-danger">Error</span>
                <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert"><span>&times;</span></button>
            </div>
        </div>
    <?php endif; ?>

    <div class="col-lg-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <strong class="card-title">Imported Excel Files</strong>

                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('import-warehouse-file')): ?>
                    <a href="<?php echo e(route('cargo-items.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="fa fa-plus"></i> Upload New
                    </a>
                <?php endif; ?>
            </div>
            <div class="card-body">
                <table class="table table-striped table-bordered">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Title</th>
                            <th>File Name</th>
                            <th>Note</th>
                            <th>Total</th>
                            <th>Imported</th>
                            <th>Duplicates</th>
                            <th>Uploaded By</th>
                            <th>Date</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $files; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $f): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($f->id); ?></td>
                            <td><?php echo e($f->title); ?></td>
                            <td>
                                <i class="fa fa-file-excel-o text-success"></i>
                                <?php echo e($f->file_name); ?>

                            </td>
                            <td><?php echo e(Str::limit($f->note, 40) ?? '—'); ?></td>
                            <td><span class="badge badge-info"><?php echo e($f->total_rows); ?></span></td>
                            <td><span class="badge badge-success"><?php echo e($f->imported_rows); ?></span></td>
                            <td>
                                <?php if($f->duplicate_rows > 0): ?>
                                    <span class="badge badge-warning"><?php echo e($f->duplicate_rows); ?></span>
                                <?php else: ?>
                                    <span class="badge badge-secondary">0</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e($f->uploader->name ?? '—'); ?></td>
                            <td><?php echo e($f->created_at->format('Y-m-d H:i')); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['view-warehouse-item', 'import-warehouse-file', 'delete-warehouse-item'])): ?>
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-warehouse-item')): ?>
                                        <a href="<?php echo e(route('cargo-items.files.view', $f->id)); ?>"
                                           class="btn btn-info btn-sm" title="View">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                    <?php endif; ?>

                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-warehouse-item')): ?>
                                        <a href="<?php echo e(route('cargo-items.files.download', $f->id)); ?>"
                                           class="btn btn-secondary btn-sm" title="Download">
                                            <i class="fa fa-download"></i>
                                        </a>
                                    <?php endif; ?>

                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-warehouse-item')): ?>
                                        <form action="<?php echo e(route('cargo-items.files.destroy', $f->id)); ?>"
                                              method="POST" class="d-inline"
                                              onsubmit="return confirm('Delete this file permanently?')">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger btn-sm" title="Delete">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="10" class="text-center text-muted">No imported files yet.</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <div class="mt-3">
                    <?php echo e($files->links('pagination::bootstrap-4')); ?>

                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/cargo_items/files_index.blade.php ENDPATH**/ ?>