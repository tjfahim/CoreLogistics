

<?php $__env->startSection('main_content'); ?>

<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Extra Shipping Marks</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li class="active">Customer Extra Shipping Marks</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">

    <?php if(session('success')): ?>
        <div class="col-sm-12">
            <div class="alert alert-success alert-dismissible fade show">
                <span class="badge badge-pill badge-success">Success</span>
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="col-sm-12">
            <div class="alert alert-danger alert-dismissible fade show">
                <span class="badge badge-pill badge-danger">Error</span>
                <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert">&times;</button>
            </div>
        </div>
    <?php endif; ?>

    <div class="col-lg-12">
        <div class="card">

            <div class="card-header d-flex justify-content-between align-items-center">
                <strong class="card-title">Extra Shipping Marks List</strong>

                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-shipping-mark')): ?>
                    <a href="<?php echo e(route('customer-extra-shipping-marks.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="fa fa-plus"></i> Add Shipping Mark
                    </a>
                <?php endif; ?>
            </div>

            <div class="card-body">

                
                <form method="GET" action="<?php echo e(route('customer-extra-shipping-marks.index')); ?>" class="mb-3">
                    <div class="input-group" style="max-width: 500px;">
                        <input type="text"
                               name="search"
                               class="form-control"
                               placeholder="Search by customer name, code, or shipping mark..."
                               value="<?php echo e($search ?? ''); ?>">
                        <div class="input-group-append">
                            <button class="btn btn-primary" type="submit">
                                <i class="fa fa-search"></i> Search
                            </button>
                            <?php if(!empty($search)): ?>
                                <a href="<?php echo e(route('customer-extra-shipping-marks.index')); ?>" class="btn btn-secondary">
                                    <i class="fa fa-times"></i> Clear
                                </a>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php if(!empty($search)): ?>
                        <small class="text-muted d-block mt-2">
                            Showing results for: <strong><?php echo e($search); ?></strong>
                            (<?php echo e($marks->total()); ?> found)
                        </small>
                    <?php endif; ?>
                </form>

                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th width="60">ID</th>
                                <th>Customer</th>
                                <th>Customer Code</th>
                                <th>Shipping Mark</th>
                                <th width="150">Created</th>
                                <th width="180">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $marks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mark): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($mark->id); ?></td>
                                    <td>
                                        <?php if($mark->customer): ?>
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-customers')): ?>
                                                <a href="<?php echo e(route('customers.edit', $mark->customer->id)); ?>">
                                                    <?php echo e($mark->customer->name); ?>

                                                </a>
                                            <?php else: ?>
                                                <?php echo e($mark->customer->name); ?>

                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($mark->customer->customer_code ?? '—'); ?></td>
                                    <td><strong><?php echo e($mark->shipping_mark); ?></strong></td>
                                    <td><?php echo e($mark->created_at->format('d M Y, h:i A')); ?></td>
                                    <td>
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any(['edit-shipping-mark', 'delete-shipping-mark'])): ?>
                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-shipping-mark')): ?>
                                                <a href="<?php echo e(route('customer-extra-shipping-marks.edit', $mark->id)); ?>"
                                                   class="btn btn-warning btn-sm">
                                                    <i class="fa fa-edit"></i> Edit
                                                </a>
                                            <?php endif; ?>

                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-shipping-mark')): ?>
                                                <form action="<?php echo e(route('customer-extra-shipping-marks.destroy', $mark->id)); ?>"
                                                      method="POST" class="d-inline delete-form">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button class="btn btn-danger btn-sm">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="6" class="text-center text-muted py-4">
                                        <?php if(!empty($search)): ?>
                                            No shipping marks found for "<strong><?php echo e($search); ?></strong>".
                                        <?php else: ?>
                                            No extra shipping marks found.
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>

                <div class="mt-3">
                    <?php echo e($marks->links('pagination::bootstrap-4')); ?>

                </div>

            </div>

        </div>
    </div>

</div>

<script>
$(document).ready(function () {
    // Confirm before delete
    $('.delete-form').on('submit', function (e) {
        e.preventDefault();
        if (confirm('Are you sure you want to delete this shipping mark?')) {
            this.submit();
        }
    });
});
</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/customer_extra_shipping_marks/index.blade.php ENDPATH**/ ?>