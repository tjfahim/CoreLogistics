

<?php $__env->startSection('main_content'); ?>
<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <strong class="card-title">Role Management</strong>
                        <a href="<?php echo e(route('roles.create')); ?>" class="btn btn-primary btn-sm">
                            <i class="fa fa-plus"></i> Add New Role
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if(session('success')): ?>
                            <div class="alert alert-success alert-dismissible fade show">
                                <?php echo e(session('success')); ?>

                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                            </div>
                        <?php endif; ?>

                        <?php if(session('error')): ?>
                            <div class="alert alert-danger alert-dismissible fade show">
                                <?php echo e(session('error')); ?>

                                <button type="button" class="close" data-dismiss="alert">&times;</button>
                            </div>
                        <?php endif; ?>

                        <table class="table table-striped table-bordered">
                            <thead>
                                <tr>
                                    <th width="50">#</th>
                                    <th>Name</th>
                                    <th>Slug</th>
                                    <th>Description</th>
                                    <th width="100">Permissions</th>
                                    <th width="80">Users</th>
                                    <th width="100">Status</th>
                                    <th width="170">Actions</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($roles->firstItem() + $key); ?></td>
                                    <td><?php echo e($role->name); ?></td>
                                    <td><code><?php echo e($role->slug); ?></code></td>
                                    <td><?php echo e(Str::limit($role->description, 50) ?? '-'); ?></td>
                                    <td>
                                        <span class="badge badge-info"><?php echo e($role->permissions_count); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge badge-secondary"><?php echo e($role->users_count); ?></span>
                                    </td>
                                    <td>
                                        <span class="badge <?php echo e($role->status ? 'badge-success' : 'badge-danger'); ?> status-badge"
                                              data-id="<?php echo e($role->id); ?>" style="cursor:pointer;">
                                            <?php echo e($role->status ? 'Active' : 'Inactive'); ?>

                                        </span>
                                    </td>
                                    <td>
                                        <div class="btn-group">
                                            <a href="<?php echo e(route('roles.show', $role->id)); ?>"
                                               class="btn btn-info btn-sm" title="View">
                                                <i class="fa fa-eye"></i>
                                            </a>
                                            <a href="<?php echo e(route('roles.edit', $role->id)); ?>"
                                               class="btn btn-warning btn-sm" title="Edit">
                                                <i class="fa fa-edit"></i>
                                            </a>
                                            <form action="<?php echo e(route('roles.destroy', $role->id)); ?>"
                                                  method="POST"
                                                  class="d-inline delete-form">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" title="Delete">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr>
                                    <td colspan="8" class="text-center">No roles found.</td>
                                </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>

                        <div class="mt-3">
                            <?php echo e($roles->links('pagination::bootstrap-4')); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
        // Delete confirm
        $('.delete-form').on('submit', function (e) {
            e.preventDefault();
            if (confirm('Are you sure you want to delete this role?')) {
                this.submit();
            }
        });

        // Toggle status via AJAX
        $('.status-badge').on('click', function () {
            var badge = $(this);
            var roleId = badge.data('id');

            $.ajax({
                url: '/admin/roles/' + roleId + '/toggle-status',
                type: 'POST',
                data: { _token: '<?php echo e(csrf_token()); ?>' },
                success: function (response) {
                    if (response.success) {
                        if (response.status == 1) {
                            badge.removeClass('badge-danger').addClass('badge-success').text('Active');
                        } else {
                            badge.removeClass('badge-success').addClass('badge-danger').text('Inactive');
                        }
                    }
                },
                error: function (xhr) {
                    alert(xhr.responseJSON?.error || 'Something went wrong');
                }
            });
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>