

<?php $__env->startSection('main_content'); ?>
<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">User Details</strong>
                        <a href="<?php echo e(route('users.index')); ?>" class="btn btn-secondary btn-sm float-right">
                            <i class="fa fa-arrow-left"></i> Back
                        </a>
                    </div>
                    <div class="card-body">

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('view-users')): ?>
                            <div class="alert alert-danger">
                                You do not have permission to view this user.
                            </div>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-users')): ?>
                            <div class="row">
                                <div class="col-md-3 text-center">
                                    <img src="<?php echo e($user->image_url); ?>" alt="<?php echo e($user->name); ?>"
                                         class="rounded-circle img-fluid"
                                         style="width: 150px; height: 150px; object-fit: cover;">
                                    <h4 class="mt-3"><?php echo e($user->name); ?></h4>
                                    <span class="badge <?php echo e($user->status == 1 ? 'badge-success' : 'badge-danger'); ?>">
                                        <?php echo e($user->status == 1 ? 'Active' : 'Inactive'); ?>

                                    </span>
                                </div>
                                <div class="col-md-9">
                                    <table class="table table-bordered">
                                        <tr>
                                            <th width="200">ID</th>
                                            <td><?php echo e($user->id); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Name</th>
                                            <td><?php echo e($user->name); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Email</th>
                                            <td><?php echo e($user->email); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Role</th>
                                            <td>
                                                <?php if($user->roleRelation): ?>
                                                    <?php
                                                        $badgeClass = match($user->roleRelation->slug) {
                                                            'superadmin' => 'badge-dark',
                                                            'admin'      => 'badge-success',
                                                            'manager'    => 'badge-primary',
                                                            default      => 'badge-secondary',
                                                        };
                                                    ?>
                                                    <span class="badge <?php echo e($badgeClass); ?>">
                                                        <?php echo e($user->roleRelation->name); ?>

                                                    </span>
                                                <?php elseif($user->role == 2): ?>
                                                    <span class="badge badge-success">Admin (legacy)</span>
                                                <?php else: ?>
                                                    <span class="badge badge-secondary">User</span>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Status</th>
                                            <td>
                                                <span class="badge <?php echo e($user->status == 1 ? 'badge-success' : 'badge-danger'); ?>">
                                                    <?php echo e($user->status == 1 ? 'Active' : 'Inactive'); ?>

                                                </span>
                                            </td>
                                        </tr>
                                        <tr>
                                            <th>Created At</th>
                                            <td><?php echo e($user->created_at->format('d M Y, h:i A')); ?></td>
                                        </tr>
                                        <tr>
                                            <th>Updated At</th>
                                            <td><?php echo e($user->updated_at->format('d M Y, h:i A')); ?></td>
                                        </tr>
                                    </table>
                                    <div class="mt-3">
                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-users')): ?>
                                            <a href="<?php echo e(route('users.edit', $user->id)); ?>" class="btn btn-warning">
                                                <i class="fa fa-edit"></i> Edit
                                            </a>
                                        <?php endif; ?>

                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-users')): ?>
                                            <?php if(auth()->id() !== $user->id): ?>
                                            <form action="<?php echo e(route('users.destroy', $user->id)); ?>"
                                                  method="POST" class="d-inline"
                                                  onsubmit="return confirm('Are you sure you want to delete this user?')">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger">
                                                    <i class="fa fa-trash"></i> Delete
                                                </button>
                                            </form>
                                            <?php endif; ?>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/users/show.blade.php ENDPATH**/ ?>