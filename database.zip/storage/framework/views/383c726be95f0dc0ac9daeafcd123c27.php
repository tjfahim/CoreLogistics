

<?php $__env->startSection('main_content'); ?>

<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Item Shipment Costs</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="<?php echo e(route('itemsshipments.index')); ?>">Item Shipments</a></li>
                    <li class="active">Costs</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">

    
    
    
    <?php if($errors->any()): ?>
        <div class="col-sm-12">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <h5 class="mb-2">
                    <i class="fa fa-exclamation-triangle"></i>
                    <strong>Please fix the following errors:</strong>
                </h5>
                <ul class="mb-0">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    
    
    
    <?php if(session('success')): ?>
        <div class="col-sm-12">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <span class="badge badge-pill badge-success">Success</span> <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="col-sm-12">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <span class="badge badge-pill badge-danger">Error</span> <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session('info')): ?>
        <div class="col-sm-12">
            <div class="alert alert-info alert-dismissible fade show" role="alert">
                <span class="badge badge-pill badge-info">Info</span> <?php echo e(session('info')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Item Shipment Info -->
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong>Item Shipment Information</strong>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <strong>Shipment Name:</strong> <?php echo e($itemShipment->shipment_name); ?>

                        </div>
                        <div class="col-md-2">
                            <strong>Total Items:</strong> <?php echo e($itemShipment->total_items); ?>

                        </div>
                        <div class="col-md-2">
                            <strong>Total Weight:</strong> <?php echo e(number_format($itemShipment->total_weight, 0)); ?> kg
                        </div>
                        <div class="col-md-2">
                            <strong>Total CBM:</strong> <?php echo e(number_format($itemShipment->total_cbm, 4)); ?>

                        </div>
                        <div class="col-md-3">
                            <strong>Status:</strong>
                            <span class="badge badge-<?php echo e($itemShipment->status === 'completed' ? 'success' : ($itemShipment->status === 'cost_calculated' ? 'warning' : 'secondary')); ?>">
                                <?php echo e(ucfirst($itemShipment->status)); ?>

                            </span>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-4">
                            <strong>Total Cost:</strong> <?php echo e(number_format($itemShipment->total_cost, 0)); ?>

                        </div>
                        <div class="col-md-4">
                            <strong>Total Paid:</strong> <?php echo e(number_format($itemShipment->total_paid, 0)); ?>

                        </div>
                        <div class="col-md-4">
                            <strong>Total Due:</strong> <?php echo e(number_format($itemShipment->total_due, 0)); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- ====================================================== -->
        <!-- Add Cost Form — ✅ ONLY if user has add-shipment-cost -->
        <!-- ====================================================== -->
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-shipment-cost')): ?>
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <strong>Add New Cost</strong>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('itemshipments.costs.store', $itemShipment->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label for="cost_type_id">Cost Type <span class="text-danger">*</span></label>
                            <select name="cost_type_id" id="cost_type_id"
                                    class="form-control <?php $__errorArgs = ['cost_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                <option value="">Select Cost Type</option>
                                <?php $__currentLoopData = $costTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $costType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($costType->id); ?>"
                                        <?php echo e(old('cost_type_id') == $costType->id ? 'selected' : ''); ?>>
                                        <?php echo e($costType->name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['cost_type_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger d-block"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group" id="agent_field" style="display:none;">
                            <label for="agent_id">Agent</label>
                            <select name="agent_id" id="agent_id"
                                    class="form-control <?php $__errorArgs = ['agent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                <option value="">Select Agent</option>
                                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($agent->id); ?>"
                                        <?php echo e(old('agent_id') == $agent->id ? 'selected' : ''); ?>>
                                        <?php echo e($agent->name); ?> - <?php echo e($agent->company_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['agent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger d-block"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="row" id="rate_row" style="display:none;">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Rate per KG</label>
                                    <input type="number" step="0.01" name="rate_per_kg" id="rate_per_kg"
                                           value="<?php echo e(old('rate_per_kg')); ?>"
                                           class="form-control <?php $__errorArgs = ['rate_per_kg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <?php $__errorArgs = ['rate_per_kg'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger d-block"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Total Weight (KG)</label>
                                    <input type="number" step="0.01" name="total_weight" id="total_weight"
                                           value="<?php echo e(old('total_weight', $itemShipment->total_weight)); ?>"
                                           class="form-control <?php $__errorArgs = ['total_weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                                    <?php $__errorArgs = ['total_weight'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <small class="text-danger d-block"><?php echo e($message); ?></small>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>
                        </div>

                        <div class="form-group" id="amount_row">
                            <label>Amount <span class="text-danger">*</span></label>
                            <input type="number" step="0.01" name="amount" id="amount"
                                   value="<?php echo e(old('amount')); ?>"
                                   class="form-control <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <?php $__errorArgs = ['amount'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger d-block"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea name="description" id="description" rows="2"
                                      class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                      placeholder="Cost description"><?php echo e(old('description')); ?></textarea>
                            <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger d-block"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <div class="form-group">
                            <label for="cost_date">Cost Date <span class="text-danger">*</span></label>
                            <input type="date" name="cost_date" id="cost_date"
                                   value="<?php echo e(old('cost_date', date('Y-m-d'))); ?>"
                                   class="form-control <?php $__errorArgs = ['cost_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                            <?php $__errorArgs = ['cost_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger d-block"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">
                            <i class="fa fa-plus"></i> Add Cost
                        </button>
                    </form>
                </div>
            </div>
        </div>
        <?php endif; ?>

        <!-- ====================================================== -->
        <!-- Costs List — column width adjusts if add form hidden  -->
        <!-- ====================================================== -->
        <div class="<?php echo e(auth()->user()->hasPermission('add-shipment-cost') ? 'col-md-8' : 'col-md-12'); ?>">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Item Shipment Costs</strong>
                    <span class="badge badge-info"><?php echo e($itemShipment->costs->count()); ?> costs</span>
                </div>
                <div class="card-body">
                    <?php if($itemShipment->costs->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Cost Type</th>
                                        <th>Agent</th>
                                        <th>Amount</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $itemShipment->costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cost->costType->name); ?></td>
                                        <td><?php echo e($cost->agent ? $cost->agent->name : 'N/A'); ?></td>
                                        <td><?php echo e(number_format($cost->amount, 0)); ?></td>
                                        <td><?php echo e(number_format($cost->paid_amount, 0)); ?></td>
                                        <td><?php echo e(number_format($cost->due_amount, 0)); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo e($cost->status === 'paid' ? 'success' : ($cost->status === 'partial' ? 'warning' : 'danger')); ?>">
                                                <?php echo e(ucfirst($cost->status)); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e(\Carbon\Carbon::parse($cost->cost_date)->format('M d, Y')); ?></td>
                                        <td>
                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-shipment-cost')): ?>
                                                <button type="button" class="btn btn-primary btn-sm"
                                                        data-toggle="modal" data-target="#paymentModal<?php echo e($cost->id); ?>">
                                                    <i class="fa fa-money-bill"></i> Pay
                                                </button>
                                            <?php endif; ?>

                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-shipment-cost')): ?>
                                                <form action="<?php echo e(route('itemshipments.costs.destroy', $cost->id)); ?>"
                                                      method="POST" class="d-inline delete-cost-form">
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('DELETE'); ?>
                                                    <button type="submit" class="btn btn-danger btn-sm">
                                                        <i class="fa fa-trash"></i>
                                                    </button>
                                                </form>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('add-shipment-cost')): ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('delete-shipment-cost')): ?>
                                                    <span class="text-muted">—</span>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <!-- Payment Modal -->
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-shipment-cost')): ?>
                                    <div class="modal fade" id="paymentModal<?php echo e($cost->id); ?>" tabindex="-1" role="dialog">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Add Payment - <?php echo e($cost->costType->name); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <form action="<?php echo e(route('itemshipments.costs.payments.store', $cost->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label>Due Amount: <?php echo e(number_format($cost->due_amount, 0)); ?></label>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="amount<?php echo e($cost->id); ?>">Payment Amount <span class="text-danger">*</span></label>
                                                            <input type="number"
                                                                   step="0.01"
                                                                   name="amount"
                                                                   id="amount<?php echo e($cost->id); ?>"
                                                                   class="form-control"
                                                                   <?php if(!$cost->costType->have_partial_payment): ?>
                                                                       value="<?php echo e(number_format($cost->due_amount, 2, '.', '')); ?>"
                                                                       readonly
                                                                   <?php endif; ?>
                                                                   required
                                                                   max="<?php echo e($cost->due_amount); ?>">
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="payment_date<?php echo e($cost->id); ?>">Payment Date <span class="text-danger">*</span></label>
                                                            <input type="date" name="payment_date" id="payment_date<?php echo e($cost->id); ?>"
                                                                   class="form-control" required value="<?php echo e(date('Y-m-d')); ?>">
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="payment_method<?php echo e($cost->id); ?>">Payment Method <span class="text-danger">*</span></label>
                                                            <select name="payment_method" id="payment_method<?php echo e($cost->id); ?>"
                                                                    class="form-control" required>
                                                                <option value="cash">Cash</option>
                                                                <option value="bank">Bank Transfer</option>
                                                                <option value="check">Check</option>
                                                                <option value="mobile_banking">Mobile Banking</option>
                                                            </select>
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="reference_no<?php echo e($cost->id); ?>">Reference No</label>
                                                            <input type="text" name="reference_no" id="reference_no<?php echo e($cost->id); ?>"
                                                                   class="form-control" placeholder="Transaction ID/Check No">
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="paid_by<?php echo e($cost->id); ?>">Paid By</label>
                                                            <input type="text" name="paid_by" id="paid_by<?php echo e($cost->id); ?>"
                                                                   class="form-control" placeholder="Person name">
                                                        </div>

                                                        <div class="form-group">
                                                            <label for="notes<?php echo e($cost->id); ?>">Notes</label>
                                                            <textarea name="notes" id="notes<?php echo e($cost->id); ?>"
                                                                      class="form-control" rows="2"
                                                                      placeholder="Payment notes"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Add Payment</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info text-center">
                            No costs added yet. Add your first cost using the form.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Payment History -->
            <?php if($itemShipment->costs->flatMap->payments->count() > 0): ?>
            <div class="card mt-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Payment History</strong>
                    <span class="badge badge-info"><?php echo e($itemShipment->costs->flatMap->payments->count()); ?> payments</span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Cost Type</th>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Reference</th>
                                    <th>Paid By</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $itemShipment->costs->flatMap->payments->sortByDesc('payment_date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($payment->itemsShipmentCost->costType->name); ?></td>
                                    <td><?php echo e(number_format($payment->amount, 0)); ?></td>
                                    <td><?php echo e(ucfirst($payment->payment_method)); ?></td>
                                    <td><?php echo e($payment->reference_no ?? 'N/A'); ?></td>
                                    <td><?php echo e($payment->paid_by ?? 'N/A'); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($payment->payment_date)->format('M d, Y')); ?></td>
                                    <td>
                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-shipment-cost')): ?>
                                            <form action="<?php echo e(route('itemshipments.payments.destroy', $payment->id)); ?>"
                                                  method="POST" class="d-inline delete-payment-form">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>
                                        <?php else: ?>
                                            <span class="text-muted">—</span>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
document.addEventListener("DOMContentLoaded", function () {
    const costTypeDropdown = document.getElementById("cost_type_id");

    // If add-shipment-cost is not granted, the form isn't in the DOM
    if (!costTypeDropdown) return;

    const agentField       = document.getElementById("agent_field");
    const rateField        = document.getElementById("rate_row");
    const amountField      = document.getElementById("amount_row");

    const amountInput = document.getElementById("amount");
    const rateInput   = document.getElementById("rate_per_kg");
    const weightInput = document.getElementById("total_weight");

    const costTypes = <?php echo json_encode($costTypes, 15, 512) ?>;

    function isTrue(v) {
        return v === true || v === "true" || v === 1 || v === "1";
    }

    function updateFormUI() {
        const selectedId = costTypeDropdown.value;
        const selectedType = costTypes.find(ct => ct.id == selectedId);

        if (!selectedId || !selectedType) {
            agentField.style.display = "none";
            rateField.style.display  = "none";
            amountField.style.display = "block";
            return;
        }

        const haveAgent = isTrue(selectedType.have_agent);
        agentField.style.display = haveAgent ? "block" : "none";
        if (!haveAgent) {
            const agentSelect = document.getElementById("agent_id");
            if (agentSelect) agentSelect.value = "";
        }

        if (selectedType.type === "per_kg") {
            rateField.style.display   = "block";
            amountField.style.display = "block";
        } else if (selectedType.type === "fixed") {
            rateField.style.display   = "none";
            amountField.style.display = "block";
            rateInput.value = "";
        } else {
            rateField.style.display   = "none";
            amountField.style.display = "block";
        }
    }

    function calculateAmount() {
        const selectedId = costTypeDropdown.value;
        const selectedType = costTypes.find(ct => ct.id == selectedId);
        if (!selectedType || selectedType.type !== "per_kg") return;

        const rate   = parseFloat(rateInput.value)   || 0;
        const weight = parseFloat(weightInput.value) || 0;

        if (rate > 0 && weight > 0) {
            amountInput.value = (rate * weight).toFixed(2);
        }
    }

    costTypeDropdown.addEventListener("change", updateFormUI);
    rateInput.addEventListener("input", calculateAmount);
    weightInput.addEventListener("input", calculateAmount);

    updateFormUI();
});

// Confirm before delete (cost & payment)
document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll('.delete-cost-form').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            if (confirm('Are you sure you want to delete this cost?')) {
                this.submit();
            }
        });
    });

    document.querySelectorAll('.delete-payment-form').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            e.preventDefault();
            if (confirm('Are you sure you want to delete this payment?')) {
                this.submit();
            }
        });
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/itemshipments/costs.blade.php ENDPATH**/ ?>