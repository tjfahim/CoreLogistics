

<?php $__env->startSection('main_content'); ?>
<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <strong class="card-title">Role Details: <?php echo e($role->name); ?></strong>
                        <div>
                            <a href="<?php echo e(route('roles.edit', $role->id)); ?>" class="btn btn-warning btn-sm">
                                <i class="fa fa-edit"></i> Edit
                            </a>
                            <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary btn-sm">
                                <i class="fa fa-arrow-left"></i> Back
                            </a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row mb-4">
                            <div class="col-md-6">
                                <table class="table table-bordered">
                                    <tr>
                                        <th width="150">Name</th>
                                        <td><?php echo e($role->name); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Slug</th>
                                        <td><code><?php echo e($role->slug); ?></code></td>
                                    </tr>
                                    <tr>
                                        <th>Description</th>
                                        <td><?php echo e($role->description ?? '-'); ?></td>
                                    </tr>
                                    <tr>
                                        <th>Status</th>
                                        <td>
                                            <span class="badge <?php echo e($role->status ? 'badge-success' : 'badge-danger'); ?>">
                                                <?php echo e($role->status ? 'Active' : 'Inactive'); ?>

                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <th>Created</th>
                                        <td><?php echo e($role->created_at->format('d M Y, h:i A')); ?></td>
                                    </tr>
                                </table>
                            </div>
                            <div class="col-md-6">
                                <div class="card bg-light">
                                    <div class="card-body text-center">
                                        <h5 class="text-muted">Total Permissions</h5>
                                        <h2 class="text-primary"><?php echo e($role->permissions->count()); ?></h2>
                                    </div>
                                </div>
                                <div class="card bg-light mt-2">
                                    <div class="card-body text-center">
                                        <h5 class="text-muted">Assigned Users</h5>
                                        <h2 class="text-info"><?php echo e($role->users->count()); ?></h2>
                                    </div>
                                </div>
                            </div>
                        </div>

                        
                        <h5 class="mb-3">Assigned Permissions</h5>
<div class="row">
    <?php $__empty_1 = true; $__currentLoopData = $permissionsByGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupName => $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <div class="col-md-6 mb-3">
            <div class="border rounded p-3 h-100">
                <h6 class="text-primary"><?php echo e($groupName); ?></h6>
                <hr class="my-2">
                <ul class="list-unstyled mb-0">
                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="mb-1">
                            <i class="fa fa-check-circle text-success"></i>
                            <?php echo e($permission->name); ?>

                            <small class="text-muted">(<?php echo e($permission->slug); ?>)</small>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <div class="col-12">
            <div class="alert alert-warning">
                No permissions assigned to this role.
            </div>
        </div>
    <?php endif; ?>
</div>
                        
                        <h5 class="mb-3 mt-4">Assigned Users (<?php echo e($role->users->count()); ?>)</h5>
                        <?php if($role->users->count() > 0): ?>
                            <table class="table table-sm table-bordered">
                                <thead>
                                    <tr>
                                        <th>#</th>
                                        <th>Name</th>
                                        <th>Email</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $role->users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($i + 1); ?></td>
                                            <td><?php echo e($user->name); ?></td>
                                            <td><?php echo e($user->email); ?></td>
                                            <td>
                                                <span class="badge <?php echo e($user->status ? 'badge-success' : 'badge-danger'); ?>">
                                                    <?php echo e($user->status ? 'Active' : 'Inactive'); ?>

                                                </span>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        <?php else: ?>
                            <div class="alert alert-info">No users assigned to this role.</div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/roles/show.blade.php ENDPATH**/ ?>