

<?php $__env->startSection('main_content'); ?>

<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title"><h1>Customer Ledger</h1></div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li class="active">Accounting / Ledger</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">

    
    <div class="row">
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <h6>Total Billed (All Customers)</h6>
                    <h3>Tk <?php echo e(number_format($grandTotalBilled, 2)); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <h6>Total Collected</h6>
                    <h3 class="text-success">Tk <?php echo e(number_format($grandTotalPaid, 2)); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-4">
            <div class="card">
                <div class="card-body text-center">
                    <h6>Total Outstanding</h6>
                    <h3 class="text-danger">Tk <?php echo e(number_format($grandTotalDue, 2)); ?></h3>
                </div>
            </div>
        </div>
    </div>

    <div class="row mt-3">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong class="card-title">Customer Balances</strong>
                    <form method="GET" class="form-inline">
                        <input type="text" name="search" value="<?php echo e($search); ?>" class="form-control form-control-sm mr-2" placeholder="Search customer, code, phone...">
                        <button class="btn btn-sm btn-primary" type="submit"><i class="fa fa-search"></i></button>
                    </form>
                </div>

                <div class="card-body table-responsive">
                    <table id="ledgerTable" class="table table-striped table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th>Customer</th>
                                <th>Code</th>
                                <th>Shipments</th>
                                <th>Total Billed</th>
                                <th>Total Paid</th>
                                <th>Total Due</th>
                                <th>Last Payment</th>
                                <th>Status</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $ledgerRows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td><?php echo e($row['customer']->name); ?></td>
                                    <td><?php echo e($row['customer']->customer_code); ?></td>
                                    <td><?php echo e($row['shipment_count']); ?></td>
                                    <td>Tk <?php echo e(number_format($row['total_billed'], 2)); ?></td>
                                    <td class="text-success">Tk <?php echo e(number_format($row['total_paid'], 2)); ?></td>
                                    <td class="text-danger">Tk <?php echo e(number_format($row['total_due'], 2)); ?></td>
                                    <td><?php echo e($row['last_payment_date'] ? \Carbon\Carbon::parse($row['last_payment_date'])->format('Y-m-d') : '—'); ?></td>
                                    <td>
                                        <?php if($row['status'] === 'clear'): ?>
                                            <span class="badge badge-success">Clear</span>
                                        <?php elseif($row['status'] === 'due'): ?>
                                            <span class="badge badge-danger">Due</span>
                                        <?php else: ?>
                                            <span class="badge badge-secondary">No Billing</span>
                                        <?php endif; ?>
                                    </td>
                                    <td>
                                        <a href="<?php echo e(route('ledger.customer', $row['customer']->id)); ?>" class="btn btn-sm btn-info">
                                            <i class="fa fa-book"></i> View Ledger
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <tr><td colspan="9" class="text-center text-muted">No customers found</td></tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

</div>

<script>
$(document).ready(function() {
    $('#ledgerTable').DataTable({
        "order": [[5, "desc"]],
        "columnDefs": [{ "orderable": false, "targets": 8 }],
        "pageLength": 25,
        "lengthMenu": [10, 25, 50, 100],
        "responsive": true
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/ledger/index.blade.php ENDPATH**/ ?>