

<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Shipment Billing: <?php echo e($itemshipment->shipment_name); ?></h2>
        <div class="btn-group">
            <a href="javascript:history.back()" class="btn btn-secondary">
                <i class="fa fa-arrow-left"></i> Back
            </a>

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-invoices')): ?>
                <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#updatePricesModal">
                    <i class="fa fa-edit"></i> Update Prices
                </button>
            <?php endif; ?>
        </div>
    </div>

    <?php if(request('highlight')): ?>
        <?php
            $highlighted = collect($billingSummary)->firstWhere('customer_id', (int) request('highlight'));
        ?>
        <?php if($highlighted): ?>
            <div class="alert alert-info d-flex justify-content-between align-items-center mb-3">
                <div>
                    <i class="fa fa-search"></i>
                    Showing invoice for <strong><?php echo e($highlighted['customer_name']); ?></strong>
                    (<?php echo e($highlighted['customer_code']); ?>).
                </div>
                <a href="<?php echo e(route('shipments.billing', $itemshipment->id)); ?>" class="btn btn-sm btn-outline-secondary">
                    Clear
                </a>
            </div>
        <?php endif; ?>
    <?php endif; ?>

    <!-- Summary Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-secondary text-white">
                <div class="card-body">
                    <h5>Total Items</h5>
                    <h3><?php echo e($totalItems); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5>Items with Price</h5>
                    <h3><?php echo e($totalPricedItems); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h5>Items without Price</h5>
                    <h3><?php echo e($totalUnpricedItems); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5>Assigned Items</h5>
                    <h3><?php echo e($totalAssignedItems); ?></h3>
                </div>
            </div>
        </div>
    </div>

    <!-- Customer Bills Table -->
    <div class="card">
        <div class="card-header">
            <h4>Customer Bills Summary</h4>
        </div>
        <div class="card-body">
            <?php if(count($billingSummary) > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Customer Code</th>
                            <th>Customer Name</th>
                            <th>Items</th>
                            <th>With Price</th>
                            <th>Without Price</th>
                            <th>Total Weight (kg)</th>
                            <th>Total Price (TK)</th>
                            <th>Paid (TK)</th>
                            <th>Due (TK)</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            $grandWeight = 0;
                            $grandPrice  = 0;
                            $grandPaid   = 0;
                            $grandDue    = 0;
                            $highlightId = (int) request('highlight');
                        ?>

                        <?php $__currentLoopData = $billingSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $totalPrice = $bill['total_price'];
                                $paid       = $bill['paid_amount'] ?? 0;
                                $due        = max($totalPrice - $paid, 0);

                                $grandWeight += $bill['total_weight'];
                                $grandPrice  += $totalPrice;
                                $grandPaid   += $paid;
                                $grandDue    += $due;

                                $isHighlighted = $highlightId && $bill['customer_id'] == $highlightId;
                            ?>
                            <tr id="customer-row-<?php echo e($bill['customer_id']); ?>"
                                class="<?php echo e($isHighlighted ? 'table-warning' : ''); ?>">
                                <td><?php echo e($bill['customer_code']); ?></td>
                                <td><?php echo e($bill['customer_name']); ?></td>
                                <td><?php echo e($bill['total_items']); ?></td>
                                <td>
                                    <?php if($bill['items_with_price'] > 0): ?>
                                        <span class="badge bg-success"><?php echo e($bill['items_with_price']); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e($bill['items_with_price']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($bill['items_without_price'] > 0): ?>
                                        <span class="badge bg-warning"><?php echo e($bill['items_without_price']); ?></span>
                                    <?php else: ?>
                                        <span class="badge bg-secondary"><?php echo e($bill['items_without_price']); ?></span>
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e(number_format($bill['total_weight'], 0)); ?></td>
                                <td>
                                    <?php if($totalPrice > 0): ?>
                                        <strong><?php echo e(number_format($totalPrice, 0)); ?></strong>
                                    <?php else: ?>
                                        <span class="text-muted">Not set</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($paid > 0): ?>
                                        <strong class="text-success"><?php echo e(number_format($paid, 0)); ?></strong>
                                    <?php else: ?>
                                        <span class="text-muted">0</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($totalPrice > 0): ?>
                                        <?php if($due <= 0): ?>
                                            <span class="badge bg-success">PAID</span>
                                        <?php else: ?>
                                            <strong class="text-danger"><?php echo e(number_format($due, 0)); ?></strong>
                                        <?php endif; ?>
                                    <?php else: ?>
                                        <span class="text-muted">—</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($bill['customer_id']): ?>
                                        <div class="d-flex flex-wrap gap-1">
                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-invoices')): ?>
                                                <a href="<?php echo e(route('customers.shipment.bill', ['customer' => $bill['customer_id'], 'itemshipment' => $itemshipment->id])); ?>"
                                                   class="btn btn-sm btn-info">
                                                   Invoice
                                                </a>
                                            <?php endif; ?>

                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('add-payment')): ?>
                                                <a href="<?php echo e(route('payments.create', ['customer' => $bill['customer_id'], 'itemshipment' => $itemshipment->id])); ?>"
                                                   class="btn btn-sm btn-success">
                                                    <i class="fa fa-money-bill-wave"></i> Receive Payment
                                                </a>
                                            <?php endif; ?>

                                            
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-payment-history')): ?>
                                                <a href="<?php echo e(route('payments.history', ['customer' => $bill['customer_id'], 'itemshipment' => $itemshipment->id])); ?>"
                                                   class="btn btn-sm btn-info">
                                                    <i class="fa fa-history"></i> Payment History
                                                </a>
                                            <?php endif; ?>

                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('view-invoices')): ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('add-payment')): ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('view-payment-history')): ?>
                                                        <span class="text-muted">—</span>
                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        </div>
                                    <?php else: ?>
                                        <span class="text-muted">No customer assigned</span>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="table-dark">
                        <tr>
                            <td colspan="2"><strong>TOTALS</strong></td>
                            <td><strong><?php echo e($totalItems); ?></strong></td>
                            <td><strong><?php echo e($totalPricedItems); ?></strong></td>
                            <td><strong><?php echo e($totalUnpricedItems); ?></strong></td>
                            <td><strong><?php echo e(number_format($grandWeight, 0)); ?> kg</strong></td>
                            <td><strong><?php echo e(number_format($grandPrice, 0)); ?></strong></td>
                            <td><strong><?php echo e(number_format($grandPaid, 0)); ?></strong></td>
                            <td><strong><?php echo e(number_format($grandDue, 0)); ?></strong></td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <?php else: ?>
            <div class="alert alert-info">
                <i class="fa fa-info-circle"></i> No items found in this shipment.
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>


<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-invoices')): ?>
<div class="modal fade" id="updatePricesModal" tabindex="-1" aria-labelledby="updatePricesModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updatePricesModalLabel">Update Item Prices</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('shipments.update-prices', $itemshipment->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fa fa-info-circle"></i> Update prices for items in this shipment. Leave empty to clear price.
                    </div>

                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Customer</th>
                                    <th>Weight (kg)</th>
                                    <th>Fixed Price ($)</th>
                                    <th>Price per kg ($)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $allItems = $itemshipment->cargoItems()->with('customer')->get();
                                ?>
                                <?php $__currentLoopData = $allItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($item->goods_name_en); ?><br>
                                        <small class="text-muted">Tracking: <?php echo e($item->tracking_no); ?></small>
                                    </td>
                                    <td><?php echo e($item->customer ? $item->customer->name : 'Unassigned'); ?></td>
                                    <td><?php echo e(number_format($item->weight_kg, 0)); ?></td>
                                    <td>
                                        <input type="number"
                                               name="prices[<?php echo e($item->id); ?>][price]"
                                               class="form-control form-control-sm"
                                               step="0.01"
                                               min="0"
                                               value="<?php echo e($item->price); ?>">
                                    </td>
                                    <td>
                                        <input type="number"
                                               name="prices[<?php echo e($item->id); ?>][price_per_kg]"
                                               class="form-control form-control-sm"
                                               step="0.01"
                                               min="0"
                                               value="<?php echo e($item->price_per_kg); ?>">
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    document.addEventListener('DOMContentLoaded', function () {
        // ---- Highlight scroll ----
        var highlightedRow = document.querySelector('.table-warning');
        if (highlightedRow) {
            highlightedRow.scrollIntoView({ behavior: 'smooth', block: 'center' });
        }

        // ---- Price validation (only if modal inputs exist) ----
        const priceInputs = document.querySelectorAll('input[name*="[price]"], input[name*="[price_per_kg]"]');

        priceInputs.forEach(input => {
            input.addEventListener('change', function () {
                const row = this.closest('tr');
                const price = row.querySelector('input[name*="[price]"]').value;
                const pricePerKg = row.querySelector('input[name*="[price_per_kg]"]').value;

                if (price && pricePerKg) {
                    alert('Please enter either Fixed Price OR Price per kg, not both.');
                    this.value = '';
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/itemshipments/billing.blade.php ENDPATH**/ ?>