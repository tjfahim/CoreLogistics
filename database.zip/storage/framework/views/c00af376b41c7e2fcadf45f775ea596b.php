<?php $__env->startSection('main_content'); ?>
<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Shipments Manage</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li class="active">Shipments</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <?php if(session('success')): ?>
        <div class="col-sm-12">
            <div class="alert alert-success"><?php echo e(session('success')); ?></div>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="col-sm-12">
            <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
        </div>
    <?php endif; ?>

    <div class="col-lg-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <strong class="card-title">Shipment List</strong>

                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('create-shipments')): ?>
                    <a href="<?php echo e(route('itemsshipments.create')); ?>" class="btn btn-primary btn-sm">
                        <i class="fa fa-plus"></i> Create Shipment
                    </a>
                <?php endif; ?>
            </div>

            <div class="card-body">
                <table id="shipmentsTable" class="table table-striped table-bordered table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Shipment Name</th>
                            <th>Shipment Date</th>
                            <th>Items Count</th>
                            <th>Status</th>
                            <th>Note</th>
                            <th>Created At</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__currentLoopData = $shipments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $shipment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($shipment->id); ?></td>
                            <td><strong><?php echo e($shipment->shipment_name); ?></strong></td>
                            <td><?php echo e($shipment->shipment_date ? $shipment->shipment_date->format('Y-m-d') : '-'); ?></td>
                            <td>
                                <span class="badge badge-info"><?php echo e($shipment->cargoItems->count()); ?> items</span>
                            </td>
                            <td>
                                <span class="badge badge-<?php echo e($shipment->status == 'draft' ? 'secondary' : ($shipment->status == 'pending' ? 'warning' : 'success')); ?>">
                                    <?php echo e(ucfirst($shipment->status)); ?>

                                </span>
                            </td>
                            <td><?php echo e($shipment->note ? Str::limit($shipment->note, 50) : '-'); ?></td>
                            <td><?php echo e($shipment->created_at->format('Y-m-d')); ?></td>
                            <td>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->any([
                                    'view-shipment-cost',
                                    'view-ctn',
                                    'view-price',
                                    'edit-shipments',
                                    'view-returns',
                                    'view-invoices',
                                    'view-shipments',
                                    'delete-shipments'
                                ])): ?>
                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-shipment-cost')): ?>
                                        <a href="<?php echo e(route('itemshipments.costs.show', $shipment->id)); ?>" class="btn btn-primary btn-sm">
                                            <i class="fa fa-dollar-sign"></i> Costs
                                        </a>
                                    <?php endif; ?>

                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-ctn')): ?>
                                        <a href="<?php echo e(route('itemshipments.edit-ctn-numbers', $shipment->id)); ?>" class="btn btn-primary btn-sm">
                                            CTN
                                        </a>
                                    <?php endif; ?>

                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-price')): ?>
                                        <a href="<?php echo e(route('itemshipments.edit-prices', $shipment->id)); ?>" class="btn btn-primary btn-sm">
                                            Prices
                                        </a>
                                    <?php endif; ?>

                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-shipments')): ?>
                                        <a href="<?php echo e(route('itemshipments.customer.assignment', $shipment->id)); ?>" class="btn btn-primary btn-sm">
                                            Customers
                                        </a>
                                    <?php endif; ?>

                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-returns')): ?>
                                        <a href="<?php echo e(route('itemsshipments.manage-returns', $shipment->id)); ?>" class="btn btn-warning btn-sm">
                                            Returns
                                        </a>
                                    <?php endif; ?>

                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-invoices')): ?>
                                        <a href="<?php echo e(route('shipments.billing', $shipment->id)); ?>" class="btn btn-sm btn-success">
                                            <i class="fa fa-file-invoice-dollar"></i> Billing
                                        </a>
                                    <?php endif; ?>

                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-shipments')): ?>
                                        <a href="<?php echo e(route('itemsshipments.show', $shipment->id)); ?>" class="btn btn-info btn-sm">
                                            <i class="fa fa-eye"></i>
                                        </a>
                                    <?php endif; ?>

                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-shipments')): ?>
                                        <a href="<?php echo e(route('itemsshipments.edit', $shipment->id)); ?>" class="btn btn-warning btn-sm">
                                            <i class="fa fa-edit"></i>
                                        </a>
                                    <?php endif; ?>

                                    
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('delete-shipments')): ?>
                                        <form action="<?php echo e(route('itemsshipments.destroy', $shipment->id)); ?>"
                                              method="POST"
                                              class="d-inline delete-form">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button class="btn btn-danger btn-sm">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>
                                <?php else: ?>
                                    <span class="text-muted">—</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#shipmentsTable').DataTable({
        "pageLength": 50,
        "lengthMenu": [ 50, 100, 200, 500, 1000 ],
        "order": [[0, 'desc']]
    });

    // Confirm before delete
    $('.delete-form').on('submit', function (e) {
        e.preventDefault();
        if (confirm('Are you sure you want to delete this shipment?')) {
            this.submit();
        }
    });
});
</script>

<style>
    .table td, .table th {
        padding: 0.5rem !important;
        vertical-align: middle !important;
        text-align: center !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/itemshipments/index.blade.php ENDPATH**/ ?>