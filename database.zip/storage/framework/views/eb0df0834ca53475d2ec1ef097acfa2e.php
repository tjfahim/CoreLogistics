

<?php $__env->startSection('main_content'); ?>

<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Update Printed CTN Numbers</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="<?php echo e(route('itemsshipments.index')); ?>">Shipments</a></li>
                    <li>
                        <a href="<?php echo e(route('itemsshipments.show', $itemshipment->id)); ?>">
                            <?php echo e($itemshipment->shipment_name); ?>

                        </a>
                    </li>
                    <li class="active">Update CTN</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">

    <?php if(session('success')): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <span class="badge badge-pill badge-success">Success</span> <?php echo e(session('success')); ?>

            <button type="button" class="close" data-dismiss="alert">&times;</button>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <span class="badge badge-pill badge-danger">Error</span> <?php echo e(session('error')); ?>

            <button type="button" class="close" data-dismiss="alert">&times;</button>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-header d-flex justify-content-between">
            <strong>Printed CTN Numbers - <?php echo e($itemshipment->shipment_name); ?></strong>
            <div>
                <a href="javascript:history.back()" class="btn btn-secondary">
                    <i class="fa fa-arrow-left"></i> Back
                </a>

                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('print-ctn')): ?>
                    <button type="button" class="btn btn-info" onclick="printCTNTable()">
                        <i class="fa fa-print"></i> Print
                    </button>
                <?php endif; ?>
            </div>
        </div>

        <div class="card-body">

            
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('view-ctn')): ?>
                <div class="alert alert-danger">
                    You do not have permission to view CTN numbers.
                </div>
            <?php endif; ?>

            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-ctn')): ?>

                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-ctn')): ?>
                    <form action="<?php echo e(route('itemshipments.update-ctn', $itemshipment->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                <?php endif; ?>

                <div class="d-flex justify-content-between mb-3">
                    <h5>Update Printed CTN Numbers</h5>

                    
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-ctn')): ?>
                        <button class="btn btn-success">
                            <i class="fa fa-save"></i> Save All
                        </button>
                    <?php endif; ?>
                </div>

                <?php
                    // Solid colors for groups
                    $colors = [
                        '#ff6b6b', '#1dd1a1', '#54a0ff', '#feca57', '#5f27cd',
                        '#10ac84', '#ff9f43', '#2e86de', '#ee5253', '#222f3e',
                        '#0abde3', '#576574', '#8395a7', '#ff6348', '#1e3799',
                    ];
                    $colorIndex = 0;
                ?>

                <?php if($groupedItems->count() > 0): ?>
                <div class="table-responsive" id="ctnTableToPrint">
                    <table class="table table-bordered table-striped">
                        <thead class="thead-dark">
                            <tr>
                                <th>#</th>
                                <th>Old Printed CTN</th>
                                <th>New Printed CTN</th>
                                <th>Written CTN</th>
                                <th>Goods Name</th>
                                <th>Weight</th>
                                <th>Status</th>
                            </tr>
                        </thead>

                        <tbody>
                            <?php $__currentLoopData = $groupedItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ctn => $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($items->count() > 1): ?>
                                    <?php
                                        $bg = $colors[$colorIndex % count($colors)];
                                        $colorIndex++;
                                    ?>
                                <?php else: ?>
                                    <?php $bg = ''; ?>
                                <?php endif; ?>

                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr style="background: <?php echo e($bg); ?>">
                                    <td><?php echo e($loop->parent->iteration); ?>.<?php echo e($loop->iteration); ?></td>
                                    <td><strong><?php echo e($item->printed_ctn_no ?? '-'); ?></strong></td>
                                    <td>
                                        
                                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-ctn')): ?>
                                            <input type="text"
                                                   name="printed_ctn[<?php echo e($item->id); ?>]"
                                                   value="<?php echo e($item->printed_ctn_no); ?>"
                                                   class="form-control form-control-sm"
                                                   placeholder="Enter new CTN (nullable)">
                                        <?php else: ?>
                                            <?php echo e($item->printed_ctn_no ?? '-'); ?>

                                        <?php endif; ?>
                                    </td>
                                    <td><?php echo e($item->written_ctn_no ?? '-'); ?></td>
                                    <td><?php echo e($item->goods_name_en); ?></td>
                                    <td><?php echo e(number_format($item->weight_kg, 0)); ?> kg</td>
                                    <td>
                                        <span class="badge badge-<?php echo e($item->status == 'packed' ? 'info' : 'secondary'); ?>">
                                            <?php echo e(ucfirst($item->status)); ?>

                                        </span>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>

                <?php else: ?>
                    <div class="alert alert-warning text-center">
                        No cargo items found.
                    </div>
                <?php endif; ?>

                
                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-ctn')): ?>
                    <div class="d-flex justify-content-end mt-3">
                        <button type="submit" class="btn btn-success btn-lg">
                            <i class="fa fa-save"></i> Save All Changes
                        </button>
                    </div>
                <?php endif; ?>

                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit-ctn')): ?>
                    </form>
                <?php endif; ?>

            <?php endif; ?>

        </div>
    </div>

</div>

<script>
function printCTNTable() {
    var el = document.getElementById('ctnTableToPrint');
    if (!el) return;

    var printContents = el.innerHTML;
    var originalContents = document.body.innerHTML;

    document.body.innerHTML = printContents;
    window.print();
    document.body.innerHTML = originalContents;
    location.reload();
}
</script>

<style>
.table td, .table th {
    vertical-align: middle !important;
}
.table {
    --bs-table-bg: transparent;
}
</style>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/itemshipments/printed_ctn.blade.php ENDPATH**/ ?>