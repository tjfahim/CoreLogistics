

<?php $__env->startSection('main_content'); ?>
<div class="content mt-3">
    <div class="animated fadeIn">
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <strong class="card-title">Edit Role: <?php echo e($role->name); ?></strong>
                        <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary btn-sm float-right">
                            <i class="fa fa-arrow-left"></i> Back
                        </a>
                    </div>
                    <div class="card-body">
                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul class="mb-0">
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>

                        <form action="<?php echo e(route('roles.update', $role->id)); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="row">
                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="name">Role Name <span class="text-danger">*</span></label>
                                        <input type="text" name="name" id="name"
                                               class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                               value="<?php echo e(old('name', $role->name)); ?>" required>
                                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-6">
                                    <div class="form-group">
                                        <label for="status">Status <span class="text-danger">*</span></label>
                                        <select name="status" id="status"
                                                class="form-control <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" required>
                                            <option value="1" <?php echo e(old('status', $role->status) == 1 ? 'selected' : ''); ?>>Active</option>
                                            <option value="0" <?php echo e(old('status', $role->status) == 0 ? 'selected' : ''); ?>>Inactive</option>
                                        </select>
                                        <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="col-md-12">
                                    <div class="form-group">
                                        <label for="description">Description</label>
                                        <textarea name="description" id="description" rows="3"
                                                  class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old('description', $role->description)); ?></textarea>
                                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="invalid-feedback"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>
                            </div>

                            
                           
<div class="card mt-3">
    <div class="card-header d-flex justify-content-between align-items-center">
        <strong>Assign Permissions</strong>
        <div>
            <button type="button" class="btn btn-sm btn-outline-primary" id="selectAllPermissions">
                <i class="fa fa-check-square-o"></i> Select All
            </button>
            <button type="button" class="btn btn-sm btn-outline-secondary" id="deselectAllPermissions">
                <i class="fa fa-square-o"></i> Deselect All
            </button>
        </div>
    </div>
    <div class="card-body">
        <div class="row">
            <?php
                $permissionsByGroup = \App\Models\Permission::grouped();
            ?>

            <?php $__empty_1 = true; $__currentLoopData = $permissionsByGroup; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $groupName => $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <div class="col-md-6 mb-3">
                    <div class="border rounded p-2 h-100">
                        <div class="d-flex justify-content-between align-items-center mb-2">
                            <strong class="text-primary"><?php echo e($groupName); ?></strong>
                            <button type="button"
                                    class="btn btn-sm btn-link toggle-group"
                                    data-group="<?php echo e(Str::slug($groupName)); ?>">
                                Toggle
                            </button>
                        </div>
                        <div class="group-permissions" data-group="<?php echo e(Str::slug($groupName)); ?>">
                            <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="custom-control custom-checkbox">
                                    <input type="checkbox"
                                           class="custom-control-input permission-checkbox"
                                           name="permissions[]"
                                           id="perm_<?php echo e($permission->id); ?>"
                                           value="<?php echo e($permission->id); ?>"
                                           <?php echo e(in_array($permission->id, old('permissions', $rolePermissions ?? [])) ? 'checked' : ''); ?>>
                                    <label class="custom-control-label" for="perm_<?php echo e($permission->id); ?>">
                                        <?php echo e($permission->name); ?>

                                        <small class="text-muted d-block">(<?php echo e($permission->slug); ?>)</small>
                                    </label>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <div class="col-12 text-center text-muted">
                    No permissions found. <a href="<?php echo e(route('permissions.create')); ?>">Create one</a>.
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>

                            <div class="mt-3">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-save"></i> Update Role
                                </button>
                                <a href="<?php echo e(route('roles.index')); ?>" class="btn btn-secondary">
                                    Cancel
                                </a>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<script>
    $(document).ready(function () {
        $('#selectAllPermissions').on('click', function () {
            $('.permission-checkbox').prop('checked', true);
        });

        $('#deselectAllPermissions').on('click', function () {
            $('.permission-checkbox').prop('checked', false);
        });

        $('.toggle-group').on('click', function () {
            var groupId = $(this).data('group');
            var checkboxes = $('.group-permissions[data-group="' + groupId + '"] .permission-checkbox');
            var allChecked = checkboxes.length === checkboxes.filter(':checked').length;
            checkboxes.prop('checked', !allChecked);
        });
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\Shipment\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>