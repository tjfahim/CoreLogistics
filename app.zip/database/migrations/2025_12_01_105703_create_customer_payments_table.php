<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('customer_payments', function (Blueprint $table) {
            $table->id();
              $table->foreignId('customer_id')->constrained()->onDelete('cascade');
                 $table->foreignId('itemshipment_id')
                  ->nullable()
                  ->constrained('items_shipments')
                  ->onDelete('cascade');
            $table->decimal('amount', 12, 2);
            $table->string('payment_method');
            $table->date('payment_date');
            $table->string('reference_no')->nullable();
            $table->text('notes')->nullable();
            $table->decimal('remaining_due', 12, 2)->default(0);
            $table->timestamps();
        });
         Schema::create('customer_payment_items', function (Blueprint $table) {
            $table->id();
            $table->foreignId('customer_payment_id')->constrained()->onDelete('cascade');
            $table->foreignId('cargo_item_id')->constrained()->onDelete('cascade');
            $table->decimal('amount', 12, 2);
            $table->timestamps();
        });

     
    }


    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
                Schema::dropIfExists('customer_payment_items');

        Schema::dropIfExists('customer_payments');
    }
};
