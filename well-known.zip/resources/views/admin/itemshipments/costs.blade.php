@extends('admin.layouts.master')

@section('main_content')

<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Item Shipment Costs</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="{{ route('itemsshipments.index') }}">Item Shipments</a></li>
                    <li class="active">Costs</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">

    <!-- Success/Error Messages -->
    @if(session('success'))
        <div class="col-sm-12">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <span class="badge badge-pill badge-success">Success</span> {{ session('success') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    @endif

    @if(session('error'))
        <div class="col-sm-12">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <span class="badge badge-pill badge-danger">Error</span> {{ session('error') }}
                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    @endif

    <div class="row">
        <!-- Item Shipment Info -->
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong>Item Shipment Information</strong>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <strong>Shipment Name:</strong> {{ $itemShipment->shipment_name }}
                        </div>
                        <div class="col-md-2">
                            <strong>Total Items:</strong> {{ $itemShipment->total_items }}
                        </div>
                        <div class="col-md-2">
                            <strong>Total Weight:</strong> {{ number_format($itemShipment->total_weight, 2) }} kg
                        </div>
                        <div class="col-md-2">
                            <strong>Total CBM:</strong> {{ number_format($itemShipment->total_cbm, 4) }}
                        </div>
                        <div class="col-md-3">
                            <strong>Status:</strong> 
                            <span class="badge badge-{{ $itemShipment->status === 'completed' ? 'success' : ($itemShipment->status === 'cost_calculated' ? 'warning' : 'secondary') }}">
                                {{ ucfirst($itemShipment->status) }}
                            </span>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-4">
                            <strong>Total Cost:</strong> ৳{{ number_format($itemShipment->total_cost, 2) }}
                        </div>
                        <div class="col-md-4">
                            <strong>Total Paid:</strong> ৳{{ number_format($itemShipment->total_paid, 2) }}
                        </div>
                        <div class="col-md-4">
                            <strong>Total Due:</strong> ৳{{ number_format($itemShipment->total_due, 2) }}
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Cost Form -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <strong>Add New Cost</strong>
                </div>
                <div class="card-body">
                    <form action="{{ route('itemshipments.costs.store', $itemShipment->id) }}" method="POST">
                        @csrf
                        <div class="form-group">
                            <label for="cost_type_id">Cost Type *</label>
                            <select name="cost_type_id" id="cost_type_id" class="form-control" required>
                                <option value="">Select Cost Type</option>
                                @foreach($costTypes as $costType)
                                    <option value="{{ $costType->id }}">{{ $costType->name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="form-group" id="agent_field" style="display:none;">
                            <label for="agent_id">Agent</label>
                            <select name="agent_id" id="agent_id" class="form-control">
                                <option value="">Select Agent</option>
                                @foreach($agents as $agent)
                                    <option value="{{ $agent->id }}">{{ $agent->name }} - {{ $agent->company_name }}</option>
                                @endforeach
                            </select>
                        </div>

                        <div class="row" id="rate_row" style="display:none;">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Rate per KG</label>
                                    <input type="number" step="0.01" name="rate_per_kg" id="rate_per_kg" class="form-control">
                                </div>
                            </div>

                           
                            <div class="col-md-6">
    <div class="form-group">
        <label>Total Weight (KG)</label>
        <input type="number" step="0.01" name="total_weight" id="total_weight" class="form-control" value="{{ $itemShipment->total_weight }}" >
    </div>
</div>
                        </div>

                        <div class="form-group" id="amount_row">
                            <label>Amount *</label>
                            <input type="number" step="0.01" name="amount" id="amount" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea name="description" id="description" class="form-control" rows="2" placeholder="Cost description"></textarea>
                        </div>

                        <div class="form-group">
                            <label for="cost_date">Cost Date *</label>
                            <input type="date" name="cost_date" id="cost_date" class="form-control" required value="{{ date('Y-m-d') }}">
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">Add Cost</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Costs List -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Item Shipment Costs</strong>
                    <span class="badge badge-info">{{ $itemShipment->costs->count() }} costs</span>
                </div>
                <div class="card-body">
                    @if($itemShipment->costs->count() > 0)
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Cost Type</th>
                                        <th>Agent</th>
                                        <th>Amount</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    @foreach($itemShipment->costs as $cost)
                                    <tr>
                                        <td>{{ $cost->costType->name }}</td>
                                        <td>{{ $cost->agent ? $cost->agent->name : 'N/A' }}</td>
                                        <td>৳{{ number_format($cost->amount, 2) }}</td>
                                        <td>৳{{ number_format($cost->paid_amount, 2) }}</td>
                                        <td>৳{{ number_format($cost->due_amount, 2) }}</td>
                                        <td>
                                            <span class="badge badge-{{ $cost->status === 'paid' ? 'success' : ($cost->status === 'partial' ? 'warning' : 'danger') }}">
                                                {{ ucfirst($cost->status) }}
                                            </span>
                                        </td>
                                        <td>{{ \Carbon\Carbon::parse($cost->cost_date)->format('M d, Y') }}</td>
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#paymentModal{{ $cost->id }}">
                                                <i class="fa fa-money-bill"></i> Pay
                                            </button>
                                            <form action="{{ route('itemshipments.costs.destroy', $cost->id) }}" method="POST" class="d-inline">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this cost?')">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>

                                    <!-- Payment Modal -->
                                    <div class="modal fade" id="paymentModal{{ $cost->id }}" tabindex="-1" role="dialog">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Add Payment - {{ $cost->costType->name }}</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <form action="{{ route('itemshipments.costs.payments.store', $cost->id) }}" method="POST">
                                                    @csrf
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label>Due Amount: ৳{{ number_format($cost->due_amount, 2) }}</label>
                                                        </div>
                                                      
                                                        <div class="form-group">
                                                            <label for="amount{{ $cost->id }}">Payment Amount *</label>
                                                            <input type="number" 
                                                                   step="0.01" 
                                                                   name="amount" 
                                                                   id="amount{{ $cost->id }}" 
                                                                   class="form-control"
                                                                   @if(!$cost->costType->have_partial_payment) 
                                                                       value="{{ number_format($cost->due_amount, 2, '.', '') }}" 
                                                                       readonly 
                                                                   @endif
                                                                   required 
                                                                   max="{{ $cost->due_amount }}">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="payment_date{{ $cost->id }}">Payment Date *</label>
                                                            <input type="date" name="payment_date" id="payment_date{{ $cost->id }}" class="form-control" required value="{{ date('Y-m-d') }}">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="payment_method{{ $cost->id }}">Payment Method *</label>
                                                            <select name="payment_method" id="payment_method{{ $cost->id }}" class="form-control" required>
                                                                <option value="cash">Cash</option>
                                                                <option value="bank">Bank Transfer</option>
                                                                <option value="check">Check</option>
                                                                <option value="mobile_banking">Mobile Banking</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="reference_no{{ $cost->id }}">Reference No</label>
                                                            <input type="text" name="reference_no" id="reference_no{{ $cost->id }}" class="form-control" placeholder="Transaction ID/Check No">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="paid_by{{ $cost->id }}">Paid By</label>
                                                            <input type="text" name="paid_by" id="paid_by{{ $cost->id }}" class="form-control" placeholder="Person name">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="notes{{ $cost->id }}">Notes</label>
                                                            <textarea name="notes" id="notes{{ $cost->id }}" class="form-control" rows="2" placeholder="Payment notes"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Add Payment</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    @endforeach
                                </tbody>
                            </table>
                        </div>
                    @else
                        <div class="alert alert-info text-center">
                            No costs added yet. Add your first cost using the form.
                        </div>
                    @endif
                </div>
            </div>

            <!-- Payment History -->
            @if($itemShipment->costs->flatMap->payments->count() > 0)
            <div class="card mt-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Payment History</strong>
                    <span class="badge badge-info">{{ $itemShipment->costs->flatMap->payments->count() }} payments</span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Cost Type</th>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Reference</th>
                                    <th>Paid By</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($itemShipment->costs->flatMap->payments->sortByDesc('payment_date') as $payment)
                                <tr>
                                    <td>{{ $payment->itemsShipmentCost->costType->name }}</td>
                                    <td>৳{{ number_format($payment->amount, 2) }}</td>
                                    <td>{{ ucfirst($payment->payment_method) }}</td>
                                    <td>{{ $payment->reference_no ?? 'N/A' }}</td>
                                    <td>{{ $payment->paid_by ?? 'N/A' }}</td>
                                    <td>{{ \Carbon\Carbon::parse($payment->payment_date)->format('M d, Y') }}</td>
                                    <td>
                                        <form action="{{ route('itemshipments.payments.destroy', $payment->id) }}" method="POST" class="d-inline">
                                            @csrf
                                            @method('DELETE')
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this payment?')">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            @endif
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Auto-calculate amount when rate and weight are entered
    $('#rate_per_kg, #total_weight').on('input', function() {
        var rate = parseFloat($('#rate_per_kg').val()) || 0;
        var weight = parseFloat($('#total_weight').val()) || 0;
        if (rate > 0 && weight > 0) {
            $('#amount').val((rate * weight).toFixed(2));
        }
    });
});

document.addEventListener("DOMContentLoaded", function() {
    const costTypeDropdown = document.getElementById("cost_type_id");
    const agentField = document.getElementById("agent_field");
    const rateField = document.getElementById("rate_row");
    const amountField = document.getElementById("amount_row");

    const amountInput = document.getElementById("amount");
    const rateInput = document.getElementById("rate_per_kg");
    const weightInput = document.getElementById("total_weight");

    const costTypes = @json($costTypes);

    function updateFormUI() {
        const selectedId = costTypeDropdown.value;
        const selectedType = costTypes.find(ct => ct.id == selectedId);

        if (!selectedId || !selectedType) return;

        console.log("Selected Type:", selectedType);

        // Fix boolean (Laravel sends true/false as strings sometimes)
        let haveAgent = selectedType.have_agent == true || selectedType.have_agent == "true";

        // Toggle agent field
        agentField.style.display = haveAgent ? "block" : "none";
        if (!haveAgent) document.getElementById("agent_id").value = "";

        // Handle type logic
        if (selectedType.type === "per_kg") {
            rateField.style.display = "block";
            amountField.style.display = "none";
            amountInput.value = "";
        }
        else if (selectedType.type === "fixed") {
            rateField.style.display = "none";
            amountField.style.display = "block";
            rateInput.value = "";
        }
        else {
            // other type
            rateField.style.display = "none";
            amountField.style.display = "block";
        }
    }

    // Auto calculate per KG amount
    function calculateAmount() {
        const selectedId = costTypeDropdown.value;
        const selectedType = costTypes.find(ct => ct.id == selectedId);

        if (!selectedType || selectedType.type !== "per_kg") return;

        let rate = parseFloat(rateInput.value) || 0;
        let weight = parseFloat(weightInput.value) || 0;

        amountInput.value = (rate * weight).toFixed(2);
    }

    // Events
    costTypeDropdown.addEventListener("change", updateFormUI);
    rateInput.addEventListener("input", calculateAmount);

    // Run once on page load
    updateFormUI();
});

document.addEventListener("DOMContentLoaded", function() {
    @foreach($itemShipment->costs as $cost)
        @if(!$cost->costType->have_partial_payment)
            const amountField{{ $cost->id }} = document.getElementById("amount{{ $cost->id }}");
            if (amountField{{ $cost->id }}) {
                amountField{{ $cost->id }}.setAttribute("readonly", "true");
                amountField{{ $cost->id }}.value = "{{ number_format($cost->due_amount, 2, '.', '') }}";
            }
        @endif
    @endforeach
});
</script>
@endsection