

<?php $__env->startSection('main_content'); ?>

<div class="content mt-4">

    <h3>Search Cargo Item by Tracking Number</h3>

    <?php if(session('error')): ?>
        <div class="alert alert-danger"><?php echo e(session('error')); ?></div>
    <?php endif; ?>

    <form action="<?php echo e(route('cargo-items.tracking-view')); ?>" method="POST" class="mt-3">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <label>Tracking Number:</label>
            <input type="text" name="tracking_no" class="form-control col-5" style="border:1px solid black" placeholder="Enter Tracking No">
        </div>

        <button type="submit" class="btn btn-primary mt-2">
            <i class="fa fa-search"></i> Search
        </button>

    </form>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jamalpur associates\resources\views/admin/cargo_items/tracking_search.blade.php ENDPATH**/ ?>