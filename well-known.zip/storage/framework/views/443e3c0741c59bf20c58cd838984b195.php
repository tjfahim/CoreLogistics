

<?php $__env->startSection('main_content'); ?>

<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Item Shipment Costs</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="<?php echo e(route('itemsshipments.index')); ?>">Item Shipments</a></li>
                    <li class="active">Costs</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">

    <!-- Success/Error Messages -->
    <?php if(session('success')): ?>
        <div class="col-sm-12">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <span class="badge badge-pill badge-success">Success</span> <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="col-sm-12">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <span class="badge badge-pill badge-danger">Error</span> <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <div class="row">
        <!-- Item Shipment Info -->
        <div class="col-md-12">
            <div class="card">
                <div class="card-header">
                    <strong>Item Shipment Information</strong>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-md-3">
                            <strong>Shipment Name:</strong> <?php echo e($itemShipment->shipment_name); ?>

                        </div>
                        <div class="col-md-2">
                            <strong>Total Items:</strong> <?php echo e($itemShipment->total_items); ?>

                        </div>
                        <div class="col-md-2">
                            <strong>Total Weight:</strong> <?php echo e(number_format($itemShipment->total_weight, 2)); ?> kg
                        </div>
                        <div class="col-md-2">
                            <strong>Total CBM:</strong> <?php echo e(number_format($itemShipment->total_cbm, 4)); ?>

                        </div>
                        <div class="col-md-3">
                            <strong>Status:</strong> 
                            <span class="badge badge-<?php echo e($itemShipment->status === 'completed' ? 'success' : ($itemShipment->status === 'cost_calculated' ? 'warning' : 'secondary')); ?>">
                                <?php echo e(ucfirst($itemShipment->status)); ?>

                            </span>
                        </div>
                    </div>
                    <div class="row mt-2">
                        <div class="col-md-4">
                            <strong>Total Cost:</strong> ৳<?php echo e(number_format($itemShipment->total_cost, 2)); ?>

                        </div>
                        <div class="col-md-4">
                            <strong>Total Paid:</strong> ৳<?php echo e(number_format($itemShipment->total_paid, 2)); ?>

                        </div>
                        <div class="col-md-4">
                            <strong>Total Due:</strong> ৳<?php echo e(number_format($itemShipment->total_due, 2)); ?>

                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Add Cost Form -->
        <div class="col-md-4">
            <div class="card">
                <div class="card-header">
                    <strong>Add New Cost</strong>
                </div>
                <div class="card-body">
                    <form action="<?php echo e(route('itemshipments.costs.store', $itemShipment->id)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                            <label for="cost_type_id">Cost Type *</label>
                            <select name="cost_type_id" id="cost_type_id" class="form-control" required>
                                <option value="">Select Cost Type</option>
                                <?php $__currentLoopData = $costTypes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $costType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($costType->id); ?>"><?php echo e($costType->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="form-group" id="agent_field" style="display:none;">
                            <label for="agent_id">Agent</label>
                            <select name="agent_id" id="agent_id" class="form-control">
                                <option value="">Select Agent</option>
                                <?php $__currentLoopData = $agents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $agent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($agent->id); ?>"><?php echo e($agent->name); ?> - <?php echo e($agent->company_name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>

                        <div class="row" id="rate_row" style="display:none;">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Rate per KG</label>
                                    <input type="number" step="0.01" name="rate_per_kg" id="rate_per_kg" class="form-control">
                                </div>
                            </div>

                           
                            <div class="col-md-6">
    <div class="form-group">
        <label>Total Weight (KG)</label>
        <input type="number" step="0.01" name="total_weight" id="total_weight" class="form-control" value="<?php echo e($itemShipment->total_weight); ?>" >
    </div>
</div>
                        </div>

                        <div class="form-group" id="amount_row">
                            <label>Amount *</label>
                            <input type="number" step="0.01" name="amount" id="amount" class="form-control" required>
                        </div>

                        <div class="form-group">
                            <label for="description">Description</label>
                            <textarea name="description" id="description" class="form-control" rows="2" placeholder="Cost description"></textarea>
                        </div>

                        <div class="form-group">
                            <label for="cost_date">Cost Date *</label>
                            <input type="date" name="cost_date" id="cost_date" class="form-control" required value="<?php echo e(date('Y-m-d')); ?>">
                        </div>

                        <button type="submit" class="btn btn-primary btn-block">Add Cost</button>
                    </form>
                </div>
            </div>
        </div>

        <!-- Costs List -->
        <div class="col-md-8">
            <div class="card">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Item Shipment Costs</strong>
                    <span class="badge badge-info"><?php echo e($itemShipment->costs->count()); ?> costs</span>
                </div>
                <div class="card-body">
                    <?php if($itemShipment->costs->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>Cost Type</th>
                                        <th>Agent</th>
                                        <th>Amount</th>
                                        <th>Paid</th>
                                        <th>Due</th>
                                        <th>Status</th>
                                        <th>Date</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $itemShipment->costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($cost->costType->name); ?></td>
                                        <td><?php echo e($cost->agent ? $cost->agent->name : 'N/A'); ?></td>
                                        <td>৳<?php echo e(number_format($cost->amount, 2)); ?></td>
                                        <td>৳<?php echo e(number_format($cost->paid_amount, 2)); ?></td>
                                        <td>৳<?php echo e(number_format($cost->due_amount, 2)); ?></td>
                                        <td>
                                            <span class="badge badge-<?php echo e($cost->status === 'paid' ? 'success' : ($cost->status === 'partial' ? 'warning' : 'danger')); ?>">
                                                <?php echo e(ucfirst($cost->status)); ?>

                                            </span>
                                        </td>
                                        <td><?php echo e(\Carbon\Carbon::parse($cost->cost_date)->format('M d, Y')); ?></td>
                                        <td>
                                            <button type="button" class="btn btn-primary btn-sm" data-toggle="modal" data-target="#paymentModal<?php echo e($cost->id); ?>">
                                                <i class="fa fa-money-bill"></i> Pay
                                            </button>
                                            <form action="<?php echo e(route('itemshipments.costs.destroy', $cost->id)); ?>" method="POST" class="d-inline">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this cost?')">
                                                    <i class="fa fa-trash"></i>
                                                </button>
                                            </form>
                                        </td>
                                    </tr>

                                    <!-- Payment Modal -->
                                    <div class="modal fade" id="paymentModal<?php echo e($cost->id); ?>" tabindex="-1" role="dialog">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Add Payment - <?php echo e($cost->costType->name); ?></h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <form action="<?php echo e(route('itemshipments.costs.payments.store', $cost->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                    <div class="modal-body">
                                                        <div class="form-group">
                                                            <label>Due Amount: ৳<?php echo e(number_format($cost->due_amount, 2)); ?></label>
                                                        </div>
                                                      
                                                        <div class="form-group">
                                                            <label for="amount<?php echo e($cost->id); ?>">Payment Amount *</label>
                                                            <input type="number" 
                                                                   step="0.01" 
                                                                   name="amount" 
                                                                   id="amount<?php echo e($cost->id); ?>" 
                                                                   class="form-control"
                                                                   <?php if(!$cost->costType->have_partial_payment): ?> 
                                                                       value="<?php echo e(number_format($cost->due_amount, 2, '.', '')); ?>" 
                                                                       readonly 
                                                                   <?php endif; ?>
                                                                   required 
                                                                   max="<?php echo e($cost->due_amount); ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="payment_date<?php echo e($cost->id); ?>">Payment Date *</label>
                                                            <input type="date" name="payment_date" id="payment_date<?php echo e($cost->id); ?>" class="form-control" required value="<?php echo e(date('Y-m-d')); ?>">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="payment_method<?php echo e($cost->id); ?>">Payment Method *</label>
                                                            <select name="payment_method" id="payment_method<?php echo e($cost->id); ?>" class="form-control" required>
                                                                <option value="cash">Cash</option>
                                                                <option value="bank">Bank Transfer</option>
                                                                <option value="check">Check</option>
                                                                <option value="mobile_banking">Mobile Banking</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="reference_no<?php echo e($cost->id); ?>">Reference No</label>
                                                            <input type="text" name="reference_no" id="reference_no<?php echo e($cost->id); ?>" class="form-control" placeholder="Transaction ID/Check No">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="paid_by<?php echo e($cost->id); ?>">Paid By</label>
                                                            <input type="text" name="paid_by" id="paid_by<?php echo e($cost->id); ?>" class="form-control" placeholder="Person name">
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="notes<?php echo e($cost->id); ?>">Notes</label>
                                                            <textarea name="notes" id="notes<?php echo e($cost->id); ?>" class="form-control" rows="2" placeholder="Payment notes"></textarea>
                                                        </div>
                                                    </div>
                                                    <div class="modal-footer">
                                                        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                                        <button type="submit" class="btn btn-primary">Add Payment</button>
                                                    </div>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    <?php else: ?>
                        <div class="alert alert-info text-center">
                            No costs added yet. Add your first cost using the form.
                        </div>
                    <?php endif; ?>
                </div>
            </div>

            <!-- Payment History -->
            <?php if($itemShipment->costs->flatMap->payments->count() > 0): ?>
            <div class="card mt-3">
                <div class="card-header d-flex justify-content-between align-items-center">
                    <strong>Payment History</strong>
                    <span class="badge badge-info"><?php echo e($itemShipment->costs->flatMap->payments->count()); ?> payments</span>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-striped table-bordered">
                            <thead class="thead-dark">
                                <tr>
                                    <th>Cost Type</th>
                                    <th>Amount</th>
                                    <th>Method</th>
                                    <th>Reference</th>
                                    <th>Paid By</th>
                                    <th>Date</th>
                                    <th>Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $itemShipment->costs->flatMap->payments->sortByDesc('payment_date'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $payment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($payment->itemsShipmentCost->costType->name); ?></td>
                                    <td>৳<?php echo e(number_format($payment->amount, 2)); ?></td>
                                    <td><?php echo e(ucfirst($payment->payment_method)); ?></td>
                                    <td><?php echo e($payment->reference_no ?? 'N/A'); ?></td>
                                    <td><?php echo e($payment->paid_by ?? 'N/A'); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($payment->payment_date)->format('M d, Y')); ?></td>
                                    <td>
                                        <form action="<?php echo e(route('itemshipments.payments.destroy', $payment->id)); ?>" method="POST" class="d-inline">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Are you sure you want to delete this payment?')">
                                                <i class="fa fa-trash"></i>
                                            </button>
                                        </form>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    // Auto-calculate amount when rate and weight are entered
    $('#rate_per_kg, #total_weight').on('input', function() {
        var rate = parseFloat($('#rate_per_kg').val()) || 0;
        var weight = parseFloat($('#total_weight').val()) || 0;
        if (rate > 0 && weight > 0) {
            $('#amount').val((rate * weight).toFixed(2));
        }
    });
});

document.addEventListener("DOMContentLoaded", function() {
    const costTypeDropdown = document.getElementById("cost_type_id");
    const agentField = document.getElementById("agent_field");
    const rateField = document.getElementById("rate_row");
    const amountField = document.getElementById("amount_row");

    const amountInput = document.getElementById("amount");
    const rateInput = document.getElementById("rate_per_kg");
    const weightInput = document.getElementById("total_weight");

    const costTypes = <?php echo json_encode($costTypes, 15, 512) ?>;

    function updateFormUI() {
        const selectedId = costTypeDropdown.value;
        const selectedType = costTypes.find(ct => ct.id == selectedId);

        if (!selectedId || !selectedType) return;

        console.log("Selected Type:", selectedType);

        // Fix boolean (Laravel sends true/false as strings sometimes)
        let haveAgent = selectedType.have_agent == true || selectedType.have_agent == "true";

        // Toggle agent field
        agentField.style.display = haveAgent ? "block" : "none";
        if (!haveAgent) document.getElementById("agent_id").value = "";

        // Handle type logic
        if (selectedType.type === "per_kg") {
            rateField.style.display = "block";
            amountField.style.display = "none";
            amountInput.value = "";
        }
        else if (selectedType.type === "fixed") {
            rateField.style.display = "none";
            amountField.style.display = "block";
            rateInput.value = "";
        }
        else {
            // other type
            rateField.style.display = "none";
            amountField.style.display = "block";
        }
    }

    // Auto calculate per KG amount
    function calculateAmount() {
        const selectedId = costTypeDropdown.value;
        const selectedType = costTypes.find(ct => ct.id == selectedId);

        if (!selectedType || selectedType.type !== "per_kg") return;

        let rate = parseFloat(rateInput.value) || 0;
        let weight = parseFloat(weightInput.value) || 0;

        amountInput.value = (rate * weight).toFixed(2);
    }

    // Events
    costTypeDropdown.addEventListener("change", updateFormUI);
    rateInput.addEventListener("input", calculateAmount);

    // Run once on page load
    updateFormUI();
});

document.addEventListener("DOMContentLoaded", function() {
    <?php $__currentLoopData = $itemShipment->costs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if(!$cost->costType->have_partial_payment): ?>
            const amountField<?php echo e($cost->id); ?> = document.getElementById("amount<?php echo e($cost->id); ?>");
            if (amountField<?php echo e($cost->id); ?>) {
                amountField<?php echo e($cost->id); ?>.setAttribute("readonly", "true");
                amountField<?php echo e($cost->id); ?>.value = "<?php echo e(number_format($cost->due_amount, 2, '.', '')); ?>";
            }
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jamalpur associates\resources\views/admin/itemshipments/costs.blade.php ENDPATH**/ ?>