

<?php $__env->startSection('main_content'); ?>
<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Manage Prices</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="<?php echo e(route('itemsshipments.index')); ?>">Shipments</a></li>
                    <li><a href="<?php echo e(route('itemsshipments.show', $itemshipment->id)); ?>"><?php echo e($itemshipment->shipment_name); ?></a></li>
                    <li class="active">Manage Prices</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <?php if(session('success')): ?>
        <div class="col-sm-12">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <span class="badge badge-pill badge-success">Success</span> <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <?php if(session('error')): ?>
        <div class="col-sm-12">
            <div class="alert alert-danger alert-dismissible fade show" role="alert">
                <span class="badge badge-pill badge-danger">Error</span> <?php echo e(session('error')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <div class="col-lg-12">
        <div class="card">
            <div class="card-header d-flex justify-content-between align-items-center">
                <strong>Manage Prices - <?php echo e($itemshipment->shipment_name); ?></strong>
                <div>
                    <a href="javascript:history.back()" 
               class="btn btn-secondary">
                <i class="fa fa-arrow-left"></i> Back
            </a>
                </div>
            </div>
            <div class="card-body">
                <!-- Shipment Summary -->
                <div class="row mb-4">
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <h6>Total Items</h6>
                                <h4 class="text-primary"><?php echo e($itemshipment->cargoItems->count()); ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <h6>Total Weight</h6>
                                <h4 class="text-info"><?php echo e(number_format($itemshipment->cargoItems->sum('weight_kg'), 2)); ?> kg</h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <h6>Current Total</h6>
                                <h4 class="text-success">৳<?php echo e(number_format($itemshipment->cargoItems->sum('price'), 2)); ?></h4>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card bg-light">
                            <div class="card-body text-center">
                                <h6>Status</h6>
                                <span class="badge badge-<?php echo e($itemshipment->status == 'draft' ? 'secondary' : ($itemshipment->status == 'pending' ? 'warning' : 'success')); ?>">
                                    <?php echo e(ucfirst($itemshipment->status)); ?>

                                </span>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Price Update Form -->
                <form action="<?php echo e(route('itemshipments.update-prices', $itemshipment->id)); ?>" method="POST" id="priceForm">
                    <?php echo csrf_field(); ?>
                    <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5>Update Item Prices (Price per KG)</h5>
                        <button type="submit" class="btn btn-success btn-lg">
                            <i class="fa fa-save"></i> Update All Prices
                        </button>
                    </div>
                    
                    <?php if($itemshipment->cargoItems->count() > 0): ?>
                        <div class="table-responsive">
                            <table class="table table-striped table-bordered">
                                <thead class="thead-dark">
                                    <tr>
                                        <th>#</th>
                                        <th>CTN NO.</th>
                                        <th>Goods Name</th>
                                        <th>Shipping Mark</th>
                                            <th>CBM</th>
                                        <th>Weight (kg)</th>
                                        <th>Current Price/KG (৳)</th>
                                        <th>New Price/KG (৳)</th>
                                        <th>Total Price (৳)</th>
                                        <th>Status</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $itemshipment->cargoItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($index + 1); ?></td>
                                        <td>
                                            <strong><?php echo e($item->printed_ctn_no); ?></strong>
                                            <?php if($item->written_ctn_no): ?>
                                                <br><small class="text-muted">(<?php echo e($item->written_ctn_no); ?>)</small>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($item->goods_name_en); ?></td>
                                        <td><?php echo e($item->shipping_mark); ?></td>
                                         <td>
                                        <?php echo e(number_format($item->length_cm, 0)); ?>x<?php echo e(number_format($item->width_cm, 0)); ?>x<?php echo e(number_format($item->height_cm, 0)); ?> = <?php echo e(number_format($item->cbm ?? 0, 6)); ?>

                                    </td>
                                        <td class="text-right"><?php echo e(number_format($item->weight_kg ?? 0, 2)); ?></td>
                                        <td class="text-right text-info">
                                            <strong><?php echo e($item->price_per_kg ? number_format($item->price_per_kg, 2) : '0.00'); ?></strong>
                                        </td>
                                        <td>
                                            <input type="number" 
                                                   name="prices[<?php echo e($item->id); ?>]" 
                                                   value="<?php echo e($item->price_per_kg ?? ''); ?>" 
                                                   step="0.01" 
                                                   min="0" 
                                                   class="form-control form-control-sm price-per-kg"
                                                   data-item-id="<?php echo e($item->id); ?>"
                                                   data-weight="<?php echo e($item->weight_kg ?? 0); ?>"
                                                   placeholder="0.00">
                                        </td>
                                        <td class="text-right total-price" id="total-price-<?php echo e($item->id); ?>">
                                            <strong class="text-success">৳<?php echo e(number_format($item->price ?? 0, 2)); ?></strong>
                                        </td>
                                        <td>
                                            <span class="badge badge-<?php echo e($item->status === 'shipping_ongoing' ? 'warning' : ($item->status === 'packed' ? 'info' : 'secondary')); ?>">
                                                <?php echo e(ucfirst($item->status)); ?>

                                            </span>
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                                <tfoot class="table-info">
                                    <tr>
                                        <td colspan="4" class="text-right"><strong>Grand Totals:</strong></td>
                                        <td class="text-right">
                                            <strong>৳<?php echo e(number_format($itemshipment->cargoItems->avg('price_per_kg'), 2)); ?></strong>
                                        </td>
                                        <td></td>
                                        <td class="text-right"><strong id="grand-total">৳<?php echo e(number_format($itemshipment->cargoItems->sum('price'), 2)); ?></strong></td>
                                        <td></td>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>

                     
                    <?php else: ?>
                        <div class="alert alert-warning text-center">
                            <i class="fa fa-exclamation-triangle"></i> No items found in this shipment.
                        </div>
                    <?php endif; ?>
                        <div class="d-flex justify-content-between align-items-center mb-3">
                        <h5>Update Item Prices (Price per KG)</h5>
                        <button type="submit" class="btn btn-success btn-lg">
                            <i class="fa fa-save"></i> Update All Prices
                        </button>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    .table td, .table th {
        padding: 0.75rem;
        vertical-align: middle;
    }
    .price-per-kg {
        min-width: 120px;
        text-align: center;
        font-weight: bold;
    }
    .total-price {
        font-weight: bold;
        min-width: 100px;
    }
    .card.bg-light {
        border: 1px solid #dee2e6;
    }
    .table tfoot {
        font-weight: bold;
    }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
    const priceInputs = document.querySelectorAll('.price-per-kg');
    const grandTotalElement = document.getElementById('grand-total');
    
    // Function to calculate total price for an item
    function calculateTotalPrice(input) {
        const itemId = input.getAttribute('data-item-id');
        const weight = parseFloat(input.getAttribute('data-weight')) || 0;
        const pricePerKg = parseFloat(input.value) || 0;
        const totalPrice = weight * pricePerKg;
        
        // Update the total price display
        const totalPriceElement = document.getElementById(`total-price-${itemId}`);
        if (totalPriceElement) {
            totalPriceElement.innerHTML = `<strong class="text-success">৳${totalPrice.toFixed(2)}</strong>`;
        }
        
        // Update grand total
        updateGrandTotal();
    }
    
    // Function to update grand total
    function updateGrandTotal() {
        let grandTotal = 0;
        
        priceInputs.forEach(input => {
            const weight = parseFloat(input.getAttribute('data-weight')) || 0;
            const pricePerKg = parseFloat(input.value) || 0;
            grandTotal += weight * pricePerKg;
        });
        
        if (grandTotalElement) {
            grandTotalElement.textContent = `৳${grandTotal.toFixed(2)}`;
        }
    }
    
    // Add event listeners to all price inputs
    priceInputs.forEach(input => {
        input.addEventListener('input', function() {
            calculateTotalPrice(this);
        });
        
        // Calculate initial totals
        calculateTotalPrice(input);
    });
});


</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tech3/public_html/shipment-demo2.techlab33.com/resources/views/admin/itemshipments/price.blade.php ENDPATH**/ ?>