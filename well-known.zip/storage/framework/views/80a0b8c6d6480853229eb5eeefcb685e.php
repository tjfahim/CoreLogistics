

<?php $__env->startSection('main_content'); ?>

<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <h1>Edit Cost Type</h1>
        </div>
    </div>

    <div class="col-sm-8">
        <div class="page-header float-right">
            <ol class="breadcrumb text-right">
                <li><a href="<?php echo e(route('cost-types.index')); ?>">Cost Types</a></li>
                <li class="active">Edit</li>
            </ol>
        </div>
    </div>
</div>

<div class="content mt-3">

    <div class="col-lg-12">
        <div class="card">
            
            <div class="card-header d-flex justify-content-between">
                <strong>Edit Cost Type</strong>
                <a href="<?php echo e(route('cost-types.index')); ?>" class="btn btn-secondary btn-sm">
                    <i class="fa fa-arrow-left"></i> Back
                </a>
            </div>

            <div class="card-body">

                <form action="<?php echo e(route('cost-types.update', $costType->id)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>

                    <div class="form-group">
                        <label class="font-weight-bold">Name</label>
                        <input type="text" name="name"
                            value="<?php echo e($costType->name); ?>"
                            class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">

                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="font-weight-bold">Type</label>
                        <select name="type" class="form-control">
                            <option value="fixed" <?php echo e($costType->type=='fixed' ? 'selected':''); ?>>Fixed</option>
                            <option value="per_kg" <?php echo e($costType->type=='per_kg' ? 'selected':''); ?>>Per KG</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="font-weight-bold">Have Agent </label>
                        <select name="have_agent" class="form-control">
                            <option value='1' <?php echo e($costType->have_agent==true ? 'selected':''); ?>>Yes</option>
                            <option value='0' <?php echo e($costType->have_agent==false ? 'selected':''); ?>>No</option>
                        </select>
                    </div>
                    <div class="form-group">
                        <label class="font-weight-bold">Have Partial Payment </label>
                        <select name="have_partial_payment" class="form-control">
                            <option value='1' <?php echo e($costType->have_partial_payment==true ? 'selected':''); ?>>Yes</option>
                            <option value='0' <?php echo e($costType->have_partial_payment==false ? 'selected':''); ?>>No</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label class="font-weight-bold">Description</label>
                        <textarea name="description" rows="3"
                                  class="form-control"><?php echo e($costType->description); ?></textarea>
                    </div>

                    <button class="btn btn-primary btn-sm px-3">
                        <i class="fa fa-save"></i> Update Cost Type
                    </button>

                </form>

            </div>

        </div>
    </div>

</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tech3/public_html/shipment-demo2.techlab33.com/resources/views/admin/cost_types/edit.blade.php ENDPATH**/ ?>