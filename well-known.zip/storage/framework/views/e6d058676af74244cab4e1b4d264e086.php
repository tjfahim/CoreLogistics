

<?php $__env->startSection('main_content'); ?>

<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Customer Manage</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li class="active">Customers</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">

    <!-- Success Message -->
    <?php if(session('success')): ?>
        <div class="col-sm-12">
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <span class="badge badge-pill badge-success">Success</span>
                <?php echo e(session('success')); ?>

                <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
        </div>
    <?php endif; ?>

    <div class="col-lg-12">
        <div class="card">

            <div class="card-header d-flex justify-content-between align-items-center">
                <strong class="card-title">Customer List</strong>

                <a href="<?php echo e(route('customers.create')); ?>" class="btn btn-primary btn-sm">
                    <i class="fa fa-plus"></i> Add Customer
                </a>
            </div>

            <div class="card-body">

                <table id="customerTable" class="table table-striped table-bordered table-hover">
                    <thead class="thead-dark">
                        <tr>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Email</th>
                            <th>Phone</th>
                            <th>Customer Code</th>
                            <th>Shipping Mark</th>
                            <th>Address</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                        <tr>
                            <td><?php echo e($c->id); ?></td>
                            <td><?php echo e($c->name); ?></td>
                            <td><?php echo e($c->email); ?></td>
                            <td><?php echo e($c->phone); ?></td>
                            <td><?php echo e($c->customer_code); ?></td>
                            <td><?php echo e($c->shipping_mark1); ?>, <?php echo e($c->shipping_mark2); ?>, <?php echo e($c->shipping_mark3); ?> <?php echo e($c->shipping_mark4); ?></td>
                            <td><?php echo e($c->address); ?></td>
                            <td>
                                <a href="<?php echo e(route('customers.edit', $c->id)); ?>" class="btn btn-warning btn-sm">
                                    <i class="fa fa-edit"></i> Edit
                                </a>

                                <form action="<?php echo e(route('customers.destroy', $c->id)); ?>" method="POST" class="d-inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button class="btn btn-danger btn-sm" onclick="return confirm('Are you sure?')">
                                        <i class="fa fa-trash"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                        <tr>
                            <td colspan="7" class="text-center text-muted">No customers found</td>
                        </tr>
                        <?php endif; ?>
                    </tbody>

                </table>
            </div>

        </div>
    </div>

</div>




<script>
$(document).ready(function() {
    $('#customerTable').DataTable({
        "order": [[0, "desc"]], // sort by ID descending
        "columnDefs": [
            { "orderable": false, "targets": 6 } // Action column not sortable
        ],
        "pageLength": 10, // rows per page
        "lengthMenu": [5, 10, 25, 50],
        "responsive": true
    });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jamalpur associates\resources\views/customers/index.blade.php ENDPATH**/ ?>