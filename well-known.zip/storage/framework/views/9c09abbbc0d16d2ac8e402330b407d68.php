

<?php $__env->startSection('main_content'); ?>
<div class="container-fluid">
    <div class="d-flex justify-content-between align-items-center mb-4">
        <h2>Shipment Billing: <?php echo e($itemshipment->shipment_name); ?></h2>
        <div class="btn-group">
            <a href="javascript:history.back()" 
               class="btn btn-secondary">
                <i class="fa fa-arrow-left"></i> Back
            </a>
            <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#updatePricesModal">
                <i class="fa fa-edit"></i> Update Prices
            </button>
            
        </div>
    </div>
    
    <!-- Summary Cards -->
    <div class="row mb-4">
        <div class="col-md-3">
            <div class="card bg-secondary text-white">
                <div class="card-body">
                    <h5>Total Items</h5>
                    <h3><?php echo e($totalItems); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-success text-white">
                <div class="card-body">
                    <h5>Items with Price</h5>
                    <h3><?php echo e($totalPricedItems); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-warning text-white">
                <div class="card-body">
                    <h5>Items without Price</h5>
                    <h3><?php echo e($totalUnpricedItems); ?></h3>
                </div>
            </div>
        </div>
        <div class="col-md-3">
            <div class="card bg-primary text-white">
                <div class="card-body">
                    <h5>Assigned Items</h5>
                    <h3><?php echo e($totalAssignedItems); ?></h3>
                </div>
            </div>
        </div>
    </div>
    
    <!-- Customer Bills Table -->
    <div class="card">
        <div class="card-header">
            <h4>Customer Bills Summary</h4>
        </div>
        <div class="card-body">
            <?php if(count($billingSummary) > 0): ?>
            <div class="table-responsive">
                <table class="table table-bordered table-hover">
                    <thead class="table-dark">
                        <tr>
                            <th>Customer Code</th>
                            <th>Customer Name</th>
                            <th>Items</th>
                            <th>With Price</th>
                            <th>Without Price</th>
                            <th>Total Weight (kg)</th>
                            <th>Total Price (TK)</th>
                            <th>Actions</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $billingSummary; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($bill['customer_code']); ?></td>
                            <td><?php echo e($bill['customer_name']); ?></td>
                            <td><?php echo e($bill['total_items']); ?></td>
                            <td>
                                <?php if($bill['items_with_price'] > 0): ?>
                                <span class="badge bg-success"><?php echo e($bill['items_with_price']); ?></span>
                                <?php else: ?>
                                <span class="badge bg-secondary"><?php echo e($bill['items_with_price']); ?></span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($bill['items_without_price'] > 0): ?>
                                <span class="badge bg-warning"><?php echo e($bill['items_without_price']); ?></span>
                                <?php else: ?>
                                <span class="badge bg-secondary"><?php echo e($bill['items_without_price']); ?></span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo e(number_format($bill['total_weight'], 2)); ?></td>
                            <td>
                                <?php if($bill['total_price'] > 0): ?>
                                <strong><?php echo e(number_format($bill['total_price'], 2)); ?></strong>
                                <?php else: ?>
                                <span class="text-muted">Not set</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if($bill['customer_id']): ?>
                                <div class="">
                                    <a href="<?php echo e(route('customers.shipment.bill', ['customer' => $bill['customer_id'], 'itemshipment' => $itemshipment->id])); ?>" 
                                       class="btn btn-sm btn-info" title="View Bill">
                                        View Bill
                                    </a>
                                   <a href="<?php echo e(route('payments.create', ['customer' => $bill['customer_id'], 'itemshipment' => $itemshipment->id])); ?>" 
           class="btn btn-sm btn-success">
            <i class="fa fa-money-bill-wave"></i> Receive Payment
        </a>
        
        <a href="<?php echo e(route('payments.history', ['customer' => $bill['customer_id'], 'itemshipment' => $itemshipment->id])); ?>" 
           class="btn btn-sm btn-info">
            <i class="fa fa-history"></i> Payment History
        </a>
                                </div>
                                <?php else: ?>
                                <span class="text-muted">No customer assigned</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                    <tfoot class="table-dark">
                        <tr>
                            <td colspan="2"><strong>TOTALS</strong></td>
                            <td><strong><?php echo e($totalItems); ?></strong></td>
                            <td><strong><?php echo e($totalPricedItems); ?></strong></td>
                            <td><strong><?php echo e($totalUnpricedItems); ?></strong></td>
                            <td>
                                <strong>
                                    <?php echo e(number_format(array_sum(array_column($billingSummary, 'total_weight')), 2)); ?> kg
                                </strong>
                            </td>
                            <td>
                                <strong>
                                    <?php echo e(number_format(array_sum(array_column($billingSummary, 'total_price')), 2)); ?>

                                </strong>
                            </td>
                            <td></td>
                        </tr>
                    </tfoot>
                </table>
            </div>
            <?php else: ?>
            <div class="alert alert-info">
                <i class="fa fa-info-circle"></i> No items found in this shipment.
            </div>
            <?php endif; ?>
        </div>
    </div>
</div>

<!-- Update Prices Modal -->
<div class="modal fade" id="updatePricesModal" tabindex="-1" aria-labelledby="updatePricesModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="updatePricesModalLabel">Update Item Prices</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('shipments.update-prices', $itemshipment->id)); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="alert alert-info">
                        <i class="fa fa-info-circle"></i> Update prices for items in this shipment. Leave empty to clear price.
                    </div>
                    
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Item</th>
                                    <th>Customer</th>
                                    <th>Weight (kg)</th>
                                    <th>Fixed Price ($)</th>
                                    <th>Price per kg ($)</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                    $allItems = $itemshipment->cargoItems()->with('customer')->get();
                                ?>
                                <?php $__currentLoopData = $allItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td>
                                        <?php echo e($item->goods_name_en); ?><br>
                                        <small class="text-muted">Tracking: <?php echo e($item->tracking_no); ?></small>
                                    </td>
                                    <td>
                                        <?php echo e($item->customer ? $item->customer->name : 'Unassigned'); ?>

                                    </td>
                                    <td><?php echo e(number_format($item->weight_kg, 2)); ?></td>
                                    <td>
                                        <input type="number" 
                                               name="prices[<?php echo e($item->id); ?>][price]" 
                                               class="form-control form-control-sm" 
                                               step="0.01" 
                                               min="0"
                                               value="<?php echo e($item->price); ?>">
                                    </td>
                                    <td>
                                        <input type="number" 
                                               name="prices[<?php echo e($item->id); ?>][price_per_kg]" 
                                               class="form-control form-control-sm" 
                                               step="0.01" 
                                               min="0"
                                               value="<?php echo e($item->price_per_kg); ?>">
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                    <button type="submit" class="btn btn-primary">Save Changes</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Auto-calculate total price when either field changes
    document.addEventListener('DOMContentLoaded', function() {
        const priceInputs = document.querySelectorAll('input[name*="[price]"], input[name*="[price_per_kg]"]');
        
        priceInputs.forEach(input => {
            input.addEventListener('change', function() {
                const row = this.closest('tr');
                const price = row.querySelector('input[name*="[price]"]').value;
                const pricePerKg = row.querySelector('input[name*="[price_per_kg]"]').value;
                const weight = parseFloat(row.querySelector('td:nth-child(3)').textContent);
                
                if (price && pricePerKg) {
                    alert('Please enter either Fixed Price OR Price per kg, not both.');
                    this.value = '';
                }
            });
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jamalpur associates\resources\views/admin/itemshipments/billing.blade.php ENDPATH**/ ?>