

<?php $__env->startSection('main_content'); ?>
<div class="breadcrumbs">
    <div class="col-sm-4">
        <div class="page-header float-left">
            <div class="page-title">
                <h1>Create Shipment</h1>
            </div>
        </div>
    </div>
    <div class="col-sm-8">
        <div class="page-header float-right">
            <div class="page-title">
                <ol class="breadcrumb text-right">
                    <li><a href="<?php echo e(route('itemsshipments.index')); ?>">Shipments</a></li>
                    <li class="active">Create Shipment</li>
                </ol>
            </div>
        </div>
    </div>
</div>

<div class="content mt-3">
    <div class="col-lg-12">
        <div class="card">
            <div class="card-header">
                <strong>Create New Shipment</strong>
            </div>
            <div class="card-body card-block">
                <form action="<?php echo e(route('itemsshipments.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <div class="row form-group">
                        <div class="col col-md-6">
                            <label for="shipment_name" class="form-label">Shipment Name</label>
                            <input type="text" class="form-control" id="shipment_name" name="shipment_name" 
                                   value="<?php echo e(old('shipment_name')); ?>" placeholder="Auto-generated if empty">
                            <?php $__errorArgs = ['shipment_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        
                        <div class="col col-md-6">
                            <label for="shipment_date" class="form-label">Shipment Date</label>
                            <input type="date" class="form-control" id="shipment_date" name="shipment_date" 
                                   value="<?php echo e(old('shipment_date')); ?>">
                            <?php $__errorArgs = ['shipment_date'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="row form-group">
                        <div class="col col-md-6">
                            <label for="status" class="form-label">Status</label>
                            <select class="form-control" id="status" name="status">
                                <option value="draft" <?php echo e(old('status') == 'draft' ? 'selected' : ''); ?>>Draft</option>
                                <option value="pending" <?php echo e(old('status') == 'pending' ? 'selected' : ''); ?>>Shipment Ongoing</option>
                                <option value="waiting_for_customs" <?php echo e(old('status') == 'waiting_for_customs' ? 'selected' : ''); ?>>Waiting for Customs</option>
                                <option value="delivered" <?php echo e(old('status') == 'delivered' ? 'selected' : ''); ?>>Delivered</option>

                            </select>
                            <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>

                    <div class="form-group">
                        <label for="note" class="form-label">Note</label>
                        <textarea class="form-control" id="note" name="note" rows="3" 
                                  placeholder="Optional notes about this shipment"><?php echo e(old('note')); ?></textarea>
                        <?php $__errorArgs = ['note'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="text-danger"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="form-group">
                        <label class="form-label">Select Items</label>
                        <?php if($items->count() > 0): ?>
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead class="thead-light">
                                        <tr>
                                            <th>
                                                <input type="checkbox" id="selectAllItems">
                                            </th>
                                            <th>ID</th>
                                            <th>Printed CTN NO.</th>
                                            <th>Written CTN NO.</th>
                                            <th>Tracking NO.</th>
                                            <th>Goods Name</th>
                                            <th>Pack No.</th>
                                            <th>Unit Pcs</th>
                                            <th>Weight (kg)</th>
                                            <th>CBM</th>
                                            <th>Shipping Mark</th>
                                            <th>Remark</th>
                                            <th>Copy</th>
                                            <th>Warehouse</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <input type="checkbox" name="selected_items[]" value="<?php echo e($item->id); ?>" 
                                                       class="item-checkbox">
                                            </td>
                                            <td><?php echo e($item->id); ?></td>
                                            <td><?php echo e($item->printed_ctn_no); ?></td>
                                            <td><?php echo e($item->written_ctn_no); ?></td>
                                            <td><?php echo e($item->tracking_no); ?></td>
                                            <td><?php echo e($item->goods_name_en); ?></td>
                                            <td><?php echo e($item->pack_no); ?></td>
                                            <td><?php echo e($item->unit_pcs); ?></td>
                                            <td><?php echo e($item->weight_kg ?? '0.00'); ?></td>
<td>
                                        <?php echo e(number_format($item->length_cm, 0)); ?>x<?php echo e(number_format($item->width_cm, 0)); ?>x<?php echo e(number_format($item->height_cm, 0)); ?> = <?php echo e(number_format($item->cbm ?? 0, 3)); ?>

                                    </td>                                            <td><?php echo e($item->shipping_mark); ?></td>
                                            <td><?php echo e($item->remark); ?></td>
                                            <td><?php echo e($item->is_copy ? 'Yes' : 'No'); ?></td>
                                            <td><?php echo e($item->warehouse); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <?php $__errorArgs = ['selected_items'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <small class="text-danger"><?php echo e($message); ?></small>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        <?php else: ?>
                            <div class="alert alert-warning">
                                No available items found. All items might already be in other shipments.
                            </div>
                        <?php endif; ?>
                    </div>

                    <input type="hidden" name="selected_items" id="selectedItemsInput">

                    <div class="form-group">
                        <button type="submit" class="btn btn-primary">Create Shipment</button>
                        <a href="<?php echo e(route('itemsshipments.index')); ?>" class="btn btn-secondary">Cancel</a>
                    </div>
                </form>
            </div>
        </div>
    </div>
</div>

<script>
$(document).ready(function() {
    $('#selectAllItems').change(function() {
        $('.item-checkbox').prop('checked', $(this).is(':checked'));
        updateSelectedItems();
    });

    // Update hidden input when checkboxes change
    $('.item-checkbox').change(function() {
        updateSelectedItems();
    });

    function updateSelectedItems() {
        const selectedItems = [];
        $('.item-checkbox:checked').each(function() {
            selectedItems.push($(this).val());
        });
        $('#selectedItemsInput').val(selectedItems.join(','));
    }

    // Set default date to today
    $('#shipment_date').val(new Date().toISOString().split('T')[0]);
});
</script>

<style>
    .table td, .table th {
        padding: 0.5rem !important;
        vertical-align: middle !important;
    }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\jamalpur associates\resources\views/admin/itemshipments/create.blade.php ENDPATH**/ ?>