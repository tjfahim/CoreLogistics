
<aside id="left-panel" class="left-panel">
        <nav class="navbar navbar-expand-sm navbar-default">

            <div class="navbar-header">
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-menu" aria-controls="main-menu" aria-expanded="false" aria-label="Toggle navigation">
                    <i class="fa fa-bars"></i>
                </button>
                <a class="navbar-brand" href="./"><img src="<?php echo e(asset('admin/images/logo.png')); ?>" alt="Logo"></a>
                <a class="navbar-brand hidden" href="./"><img src="<?php echo e(asset('admin/images/logo2.png')); ?>" alt="Logo"></a>
            </div>
            <div id="main-menu" class="main-menu collapse navbar-collapse">
                <ul class="nav navbar-nav">
                    <!-- Dashboard -->
                    <li class="<?php echo e(request()->is('admin/dashboard') || request()->is('/') ? 'active' : ''); ?>">
                        <a href="/admin/dashboard"> 
                            <i class="menu-icon fa fa-dashboard"></i>Dashboard 
                        </a>
                    </li>
                    
                 
                    
                    <!-- Inventory -->
                    <li class="menu-title">WARE HOUSE</li>
                    
                  
                    <li class="<?php echo e(request()->routeIs('cargo-items.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('cargo-items.index')); ?>">
                            <i class="menu-icon fa fa-cubes"></i> China Warehouse
                        </a>
                    </li>
                    <li class="<?php echo e(request()->routeIs('cargo-items.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('cargo-items.index')); ?>">
                            <i class="menu-icon fa fa-cubes"></i> BD Warehouse
                        </a>
                    </li>
                    
                    
                    
                    <!-- Operations -->
                    <li class="menu-title">OPERATIONS</li>

                    <li class="<?php echo e(request()->routeIs('itemsshipments.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('itemsshipments.index')); ?>">
                            <i class="menu-icon fa fa-truck"></i> Shipments
                        </a>
                    </li>
          

                    <!-- Reports -->
                    <li class="menu-title">REPORTS</li>
                    <li class="<?php echo e(request()->routeIs('reports.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('reports.dashboard')); ?>">
                            <i class="menu-icon fa fa-truck"></i> Dashboard Reports
                        </a>
                    </li>
                    
                       <!-- Master Data -->
                    <li class="menu-title">MASTER DATA</li>
                    
                    <li class="<?php echo e(request()->routeIs('customers.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('customers.index')); ?>">
                            <i class="menu-icon fa fa-users"></i> Customers
                        </a>
                    </li>
                  
                    
                    <li class="<?php echo e(request()->routeIs('agents.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('agents.index')); ?>">
                            <i class="menu-icon fa fa-users"></i> Agents
                        </a>
                    </li>
                    
                    <li class="<?php echo e(request()->routeIs('cost-types.*') ? 'active' : ''); ?>">
                        <a href="<?php echo e(route('cost-types.index')); ?>">
                            <i class="menu-icon fa fa-list-alt"></i> Cost Types
                        </a>
                    </li>
                   
                </ul>
            </div>
        </nav>
    </aside><?php /**PATH C:\xampp\htdocs\jamalpur associates\resources\views/admin/layouts/sidebar.blade.php ENDPATH**/ ?>